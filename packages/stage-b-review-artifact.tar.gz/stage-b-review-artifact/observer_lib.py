"""Stage B log-only observer: shared by qualification, task runs and analysis.

Two receipts, neither of which changes what any process executes:
  * an executed-source recorder (a Python audit hook loaded from a .pth file in
    the task's virtualenv, outside the repository) that logs every .py/.pyc
    file a Python process opens for reading under the watched roots, with the
    sha256 of the bytes at that moment, plus the modules it ended up with;
  * a filesystem poller (in the runner, outside the sandbox) that records the
    sha256 of every repository .py file at start and whenever it changes.

Classification (temporal / origin mismatch) uses only these receipts.
"""
import hashlib
import json
import os
import threading
import time
from pathlib import Path

HOOK_SOURCE = r'''
# _stageb_origin.py: log-only executed-source recorder (Stage B observer).
# Never alters imports or execution; every failure is swallowed.
try:
    import os as _os, sys as _sys, json as _json, time as _time, hashlib as _hashlib
    import atexit as _atexit, threading as _threading
    _here = _os.path.dirname(_os.path.abspath(__file__))
    with open(_os.path.join(_here, '_stageb_origin_config.json')) as _f:
        _cfg = _json.load(_f)
    _roots = tuple(_os.path.realpath(r) + _os.sep for r in _cfg['roots'])
    _logdir = _cfg['log_dir']
    _state = _threading.local()
    _records = []
    _start = _time.time()

    def _stageb_hook(event, args):
        if event != 'open' or getattr(_state, 'busy', False):
            return
        try:
            path = args[0]
            if path is None or isinstance(path, int):
                return
            path = _os.fsdecode(path)
            if not (path.endswith('.py') or path.endswith('.pyc')):
                return
            mode = args[1] if len(args) > 1 else None
            if isinstance(mode, str) and any(c in mode for c in 'wax+'):
                return
            ap = _os.path.realpath(path)
            if not ap.startswith(_roots):
                return
            _state.busy = True
            try:
                with open(ap, 'rb') as fh:
                    data = fh.read()
                st = _os.stat(ap)
                _records.append({'t': _time.time(), 'path': ap,
                                 'sha256': _hashlib.sha256(data).hexdigest(),
                                 'mtime_ns': st.st_mtime_ns, 'size': st.st_size,
                                 'pyc_header': data[:16].hex() if ap.endswith('.pyc') else None})
            finally:
                _state.busy = False
        except Exception:
            pass

    def _stageb_dump():
        try:
            _state.busy = True
            mods = {}
            for name, mod in list(_sys.modules.items()):
                f = getattr(mod, '__file__', None)
                if f:
                    rf = _os.path.realpath(f)
                    if rf.startswith(_roots):
                        mods[name] = {'file': rf, 'cached': getattr(mod, '__cached__', None)}
            out = {'pid': _os.getpid(), 'ppid': _os.getppid(), 'start': _start, 'end': _time.time(),
                   'argv': list(_sys.argv), 'cwd': _os.getcwd(), 'executable': _sys.executable,
                   'dont_write_bytecode': bool(_sys.dont_write_bytecode),
                   'reads': _records, 'modules': mods}
            _os.makedirs(_logdir, exist_ok=True)
            p = _os.path.join(_logdir, '%d-%d.json' % (_os.getpid(), _time.time_ns()))
            with open(p, 'w') as fh:
                _json.dump(out, fh)
        except Exception:
            pass

    _sys.addaudithook(_stageb_hook)
    _atexit.register(_stageb_dump)
except Exception:
    pass
'''


def sha256_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def install_hook(python, roots, log_dir):
    """Install the recorder into the virtualenv of `python` (site-packages only)."""
    import subprocess
    site = subprocess.run([python, '-c', "import sysconfig;print(sysconfig.get_paths()['purelib'])"],
                          capture_output=True, text=True, check=True).stdout.strip()
    site = Path(site)
    (site / '_stageb_origin.py').write_text(HOOK_SOURCE)
    (site / '_stageb_origin_config.json').write_text(json.dumps(
        {'roots': [str(Path(r).resolve()) for r in roots], 'log_dir': str(log_dir)}))
    (site / 'zz_stageb_origin.pth').write_text('import _stageb_origin\n')
    return {'site_packages': str(site), 'hook_sha256': hashlib.sha256(HOOK_SOURCE.encode()).hexdigest(),
            'roots': [str(Path(r).resolve()) for r in roots], 'log_dir': str(log_dir)}


def load_origin_logs(log_dir):
    logs = []
    for p in sorted(Path(log_dir).glob('*.json')):
        try:
            logs.append(json.loads(p.read_text()))
        except Exception:
            pass
    return sorted(logs, key=lambda x: x['start'])


class FsPoller:
    """Poll .py files under root (skipping .git) and log sha256 on start and on every change."""

    def __init__(self, root, log_path, interval=0.1):
        self.root = Path(root).resolve()
        self.log_path = Path(log_path)
        self.interval = interval
        self._stop = threading.Event()
        self._seen = {}
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def _scan(self):
        cur = {}
        for dirpath, dirnames, filenames in os.walk(self.root):
            dirnames[:] = [d for d in dirnames if d != '.git']
            for fn in filenames:
                if fn.endswith('.py'):
                    p = os.path.join(dirpath, fn)
                    try:
                        st = os.stat(p)
                        cur[p] = (st.st_mtime_ns, st.st_size, st.st_ino)
                    except FileNotFoundError:
                        pass
        return cur

    def _emit(self, fh, kind, path, sig):
        rec = {'t': time.time(), 'event': kind, 'path': path}
        if sig is not None:
            try:
                rec.update(sha256=sha256_file(path), mtime_ns=sig[0], size=sig[1])
            except FileNotFoundError:
                rec.update(event='deleted')
        fh.write(json.dumps(rec) + '\n')

    def _loop(self):
        with open(self.log_path, 'a') as fh:
            first = True
            while True:
                cur = self._scan()
                for p, sig in cur.items():
                    if p not in self._seen:
                        self._emit(fh, 'initial' if first else 'created', p, sig)
                    elif self._seen[p] != sig:
                        self._emit(fh, 'modified', p, sig)
                for p in set(self._seen) - set(cur):
                    self._emit(fh, 'deleted', p, None)
                self._seen = cur
                fh.flush()
                first = False
                if self._stop.wait(self.interval):
                    break

    def start(self):
        self._thread.start()
        deadline = time.time() + 30
        while not self.log_path.exists() and time.time() < deadline:
            time.sleep(0.01)
        return self

    def stop(self):
        self._stop.set()
        self._thread.join(timeout=10)


def load_fs_timeline(log_path):
    tl = {}
    for line in Path(log_path).read_text().splitlines():
        r = json.loads(line)
        tl.setdefault(r['path'], []).append(r)
    for v in tl.values():
        v.sort(key=lambda r: r['t'])
    return tl


def hash_at(timeline, path, t):
    """sha256 of `path` per the poller at wall time t (None if absent/unknown)."""
    best = None
    for r in timeline.get(path, []):
        if r['t'] <= t:
            best = r
        else:
            break
    if best is None or best['event'] == 'deleted':
        return None
    return best.get('sha256')


def changed_between(timeline, path, t0, t1):
    return [r for r in timeline.get(path, []) if t0 < r['t'] <= t1 and r['event'] != 'initial']


def classify_process(proc, timeline, repo_root, env_site=None, slack=0.15):
    """Return per-process receipts: temporal and origin mismatches (log-only facts)."""
    repo = str(Path(repo_root).resolve()) + os.sep
    out = {'pid': proc['pid'], 'argv': proc['argv'], 'cwd': proc['cwd'], 'start': proc['start'],
           'end': proc['end'], 'repo_reads': 0, 'temporal': [], 'origin': [], 'stale_pyc': []}
    for r in proc['reads']:
        path = r['path']
        if path.startswith(repo) and path.endswith('.py'):
            out['repo_reads'] += 1
            # temporal: the bytes this process read were replaced before it ended
            later = changed_between(timeline, path, r['t'] - slack, proc['end'] + slack)
            end_hash = hash_at(timeline, path, proc['end'] + slack)
            if later and end_hash is not None and end_hash != r['sha256']:
                out['temporal'].append({'path': path, 'read_sha256': r['sha256'],
                                        'sha256_at_process_end': end_hash,
                                        'changes': [{'t': c['t'], 'sha256': c.get('sha256')} for c in later]})
        elif env_site and path.startswith(str(Path(env_site).resolve()) + os.sep) and path.endswith('.py'):
            rel = os.path.relpath(path, str(Path(env_site).resolve()))
            for cand in (os.path.join(repo, rel), os.path.join(repo, 'src', rel)):
                ws_hash = hash_at(timeline, cand, r['t'] + slack)
                if ws_hash is not None and ws_hash != r['sha256']:
                    out['origin'].append({'executed': path, 'repository_file': cand,
                                          'executed_sha256': r['sha256'], 'repository_sha256': ws_hash})
        if path.endswith('.pyc') and r.get('pyc_header') and path.startswith(repo):
            hdr = bytes.fromhex(r['pyc_header'])
            flags = int.from_bytes(hdr[4:8], 'little')
            if flags == 0:  # timestamp-based pyc
                mtime = int.from_bytes(hdr[8:12], 'little')
                size = int.from_bytes(hdr[12:16], 'little')
                src = os.path.join(os.path.dirname(os.path.dirname(path)),
                                   os.path.basename(path).split('.')[0] + '.py')
                srcs = [x for x in timeline.get(src, []) if x['t'] <= r['t'] + slack and x['event'] != 'deleted']
                if srcs:
                    s = srcs[-1]
                    if (s['mtime_ns'] // 1_000_000_000) & 0xFFFFFFFF != mtime or (s['size'] & 0xFFFFFFFF) != size:
                        out['stale_pyc'].append({'pyc': path, 'source': src})
    out['temporal_mismatch'] = bool(out['temporal'])
    out['origin_mismatch'] = bool(out['origin'] or out['stale_pyc'])
    return out
