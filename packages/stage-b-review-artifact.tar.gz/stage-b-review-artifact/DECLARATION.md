# Stage B pilot declaration (sealed before any benchmark task reaches a model)

Written 2026-11-14 ~23:50 America/New_York. Sealed by `seal.py` into `SEAL.json`
after the observer qualification passes. Governs, together with
`PROTOCOL.txt` (sha256 ab84cac8...), `AMENDMENT-01.md` and `AMENDMENT-02.md`.
AMENDMENT-02 adds a later, model-free re-grading and recheck on AWS Linux.
It does not change the primary outcome or the continuation gate.

## State at sealing
- Admitted: psf__requests-3362, pallets__flask-4045, pallets__flask-4992.
- Not admitted: psf__requests-1963 (`admission/summary.json`).
- Re-qualification passed:
  - A'0: `qualification/a0-attempt-2`, after the single launcher correction
    documented in `A0-CORRECTION.txt`;
  - A'1: `qualification/a1-attempt-1`, learned planning, gpt-6.1-sol,
    CLI 0.166.0-alpha.5.1.
- Observer qualification: `observer-qualification/result-3.json`, attempt 3.
  - Attempts 1–2 failed only on the sandbox control's CLI invocation.
  - Controls T+/T-, O+/O- and SB all passed. SB ran under
    `codex sandbox -P :workspace`, where an outside write was denied, and the
    recorder still wrote its /tmp log.
  - The same classification functions are used in analysis.

## Launch
- Order: psf__requests-3362, then pallets__flask-4045, then
  pallets__flask-4992, one at a time with `run_task.py`.
- One attempt per task.
  - A launch that reached the model is never repeated.
  - A pre-model setup failure is preserved under `runs/_pre-model-failures/`
    and may be rebuilt.
- Setup: everything below is fixed by AMENDMENT-01 and implemented in `run_task.py`.
  - Workspace and history: `~/sbwork/<id>/repo` holds a scrubbed history,
    with no commit newer than the base reachable or present.
  - Environment: `~/sbwork/<id>/env`, built by the admitted recipe and
    constrained to the admitted freeze.
  - Activation: the virtualenv is activated through PATH and VIRTUAL_ENV,
    and a login-shell probe must resolve `python` and `pytest` inside it.
  - Task text: "Resolve the following issue in this repository." followed
    by the issue text.
  - Planning: learned, with `plan=None`.
  - Budget: 8 execution turns and 900 s.
  - Model: gpt-6.1-sol at medium effort, workspace-write sandbox.
- During the model session, `oracle/`, `admission/` and `cache/` are
  chmod 000 and are restored afterwards.

## Receipts (log-only)
- Native observable events, with reasoning and streaming deltas dropped.
- The filesystem poller's repository .py hashes, every 0.1 s.
- The executed-source recorder: an audit hook in the virtualenv's
  site-packages. It logs to /tmp and the log is copied into `runs/<id>/`.
- The final patch, snapshot and pip freeze before and after the run.

## Analysis (`analyze_task.py`, no model)
1. **Exposure audit.** Any command touching oracle/admission/cache, the
   archive, the dataset, Codex state or other tasks makes that task
   *inconclusive*.
2. **Held-out grading (SWE-bench procedure).**
   - Fresh base environment by the same recipe.
   - Final patch applied, test files reset, developer test patch applied.
   - FAIL_TO_PASS and PASS_TO_PASS run twice.
   - `resolved` means both runs pass everything.
   - `wrong_code_supported` means COMPLETED and not resolved.
3. **Capable serial final-check baseline.**
   - Each test-like command that exited 0 during the run is re-run twice
     *as run* and twice *source-forced* (PYTHONPATH = repository, no
     bytecode, caches cleared) on the frozen final source.
   - Processes and seconds are reported.
4. **Primary outcome** (PROTOCOL.txt, unchanged).
   - Requirements:
     - an accepted current-source assertion that genuinely passed earlier;
     - fresh source-correct checking at the accepted revision fails (both
       source-forced rechecks);
     - executed-source / poller receipts confirm a temporal or origin
       mismatch for that command's processes;
     - the evidence is linked to the required criterion and the MemTrace
       acceptance event from the saved runtime;
     - two fresh confirmation processes.
   - The automatic pre-screen only proposes candidates; each is linked and
     recorded by hand, with receipts.
   - Flakiness, dependency changes, hidden writes or uncertain bindings are
     *inconclusive*.
   - Prose claims, or failure on a different held-out test, are not primary.
5. **Reported for every task:**
   - completion verdict, resolved, wrong-code-supported, exposure;
   - native commands, Python and test processes;
   - temporal opportunities (a repository .py file changed while a Python
     process was alive), and temporal / origin mismatch processes;
   - processes that loaded an installed copy of the package;
   - recheck processes and time;
   - model usage and wall time.

## Continuation (PROTOCOL.txt, unchanged)
- Expansion (pytest-5221, pytest-7490, pylint-7993, pylint-5859) runs only if
  ≥1 primary case is confirmed with complete receipts and the serial baseline
  is valid.
- Otherwise the natural variant stops with its nulls.
- No sample increase after a null.

## Known limits, declared before outcomes
- The qualified launcher sets `PYTHONDONTWRITEBYTECODE=1` for the CLI, and
  agent commands inherit it, so no new .pyc files are written. The
  stale-bytecode origin route is therefore effectively closed in this
  configuration, and this is reported as such.
- CLI 0.166 reports command start and completion together (duration 0), so
  temporal facts come from the poller and the recorder, not from native
  timestamps.
- The recorder only sees Python processes started from the task virtualenv.
  Processes under other interpreters are counted as unobserved.
- This is native macOS execution, not the SWE-bench Docker harness, and not
  a leaderboard result.
- Counts describe this purposive three-task cohort only.
