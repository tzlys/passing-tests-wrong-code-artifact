"""analyze_task_v2.py with the grading environment built by run_task_v2 (HARNESS-CORRECTIONS-02).

  ~/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python -B analyze_task_v3.py <instance_id>
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_task_v2  # noqa: E402
import analyze_task  # noqa: E402
import analyze_task_v2  # noqa: E402

if __name__ == '__main__':
    analyze_task.rt = run_task_v2
    analyze_task_v2.main()
