# Analysis correction 01: process-end slack in the temporal classifier

Written 2026-11-15 ~01:20 America/New_York, after the first task
(psf__requests-3362) ran and **its receipts had been inspected**. This
correction was therefore found from data. It is disclosed as such.

## What was wrong
Sealed `observer_lib.classify_process` (v1) widened the process end by
`slack = 0.15 s` when it looked for replacements of the bytes a process had
read. A change the poller detected up to 0.15 s *after* a process exited was
therefore counted as a change *during* the process.

## How it was found
In requests-3362, v1 flagged pid 6294 (a pytest run that exited 1) as a
temporal mismatch. Receipts:
- the process ran 91.341–91.980 s after the session start;
- the native command completed at 92.005 s;
- the following fileChange item started at 92.010 s;
- the poller detected the replacement of `requests/models.py` and
  `requests/utils.py` at 92.121 s.

The edit came after the test process, so v1's flag was a false positive.

## Correction (analysis only)
`observer_classify_v2.classify_process`:
- **Temporal mismatch** only when the poller detected a replacement of the
  read bytes at or before the process end.
- **Boundary-ambiguous**: a replacement detected within one poll interval
  (0.1 s) after the end. It is reported separately and is never a mismatch.
- **Origin check** uses the repository hash at the read time, with no slack.

The correction can only remove positives; it cannot create them.

## What did not change
- Recorder, poller, runner, receipts and sealed files (`SEAL.json` still
  verifies).
- Outcome definitions and the continuation gate.

## Requalification
`classifier_v2_qualify.py` reruns T+, T-, O+ and O- on fresh receipts and
adds **T-late** (the file is replaced immediately after the process exits).
- v2 must classify all five controls correctly.
- v1 misclassifying T-late is expected and recorded.
- Local dry run: v2 5/5 correct; v1 wrong only on T-late.

## Reporting
For every task, `analyze_task_v2.py` reports:
- the v2 classification;
- v1's counts, and the pids flagged only by v1;
- boundary-ambiguous processes.

The paper reports v2 and mentions this correction and its trigger.
