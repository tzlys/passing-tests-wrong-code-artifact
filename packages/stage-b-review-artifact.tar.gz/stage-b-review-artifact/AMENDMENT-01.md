# Amendment 01 to the natural-execution protocol (pre-model)

Written 2026-11-14 ~22:30 America/New_York, after source/test admission and
before any Stage B model exposure. Model calls in Stage B so far: 0.
Base protocol: `13-natural-execution-qualification/artifacts/PROTOCOL.txt`
(sha256 ab84cac8...), selection.json (sha256 2b2cb1c7...). Everything not
changed here stays as sealed.

## Author decisions (Yansong Li, 2026-11-14 21:57 ET)
1. Stage B uses MemTrace's own learned planning: `RunRequest.plan = None`,
   so the model writes the native Codex Plan and MemTrace projects it into
   Milestones and completion criteria. No analyst-written criterion, file
   name or test name is supplied. The October Stage A pass covered only a
   supplied criterion, so learned planning needs its own qualification (A').
2. The installed CLI changed from 0.162.0-alpha.17.2 to 0.166.0-alpha.5.1
   (sha256 recorded in preflight). The October allowance of two model-bearing
   smokes is spent, so this amendment authorizes one new qualification.

## Stage A' (re-qualification)
- A'0, zero inference: generate and save the installed App Server schema
  through the same launcher, run MemTrace's schema probe, and complete the
  `initialize` handshake. If supported, list model ids. No thread or turn is
  started. One pre-model launcher correction is allowed if this step fails;
  a second failure stops Stage B.
- A'1, exactly one model-bearing attempt: same benign fixture as October
  (`subject.py`, `test_subject.py`, an already passing assertion), learned
  planning, gpt-6.1-sol at medium effort, workspace-write sandbox, built-in
  OpenAI provider through local ChatGPT auth, at most 2 execution turns and
  a 300 s watchdog.
  - It qualifies only if all of the following hold:
    - a native Plan is projected into at least one Milestone with a criterion;
    - at least one real native command completes;
    - MemTrace returns COMPLETED;
    - a fresh run of the same assertion passes;
    - the fixture is byte-identical.
  - Retries:
    - No quality retry.
    - MemTrace's own built-in retry of a planning turn that failed without a
      plan is part of the stack and is recorded.
  - If A'1 fails after at least one turn request, stop Stage B and report
    admission plus the failed re-qualification.
  - If A'1 fails before any turn request (zero inference), that is a setup
    failure. It may be corrected once before the model is reached, and that
    correction is the same single allowance as A'0's. The total allowed is
    one pre-model correction across A'0 and A'1.

## Stage B contract exposure (fixed now)
- The task text given to the model is
  `Resolve the following issue in this repository.` followed by the issue
  text verbatim, as stored in `tasks/<id>/problem_statement.md`.
- The task text includes nothing else: no hidden tests, test names, file
  names, reference patch, hypothesis, timing hint or request for parallel
  work. The planning context is empty.
- Workspace:
  - a fresh checkout at the base commit;
  - SWE-bench-style removal of future history, remotes and later tags;
  - the official v4.1.0 environment recipe, exactly as admitted (including
    the recorded PyYAML build correction for flask-4045);
  - oracle files outside the workspace.
- Afterwards, the command log is audited for any access to the oracle
  paths; any access makes that task inconclusive.
- Budget, outcomes, observer qualification and continuation gates are
  unchanged from PROTOCOL.txt: 8 execution turns and 15 min per task, no
  task replacement, and no sample increase after a null result.

## Admission record
Admitted under the sealed admission rule:
- psf__requests-3362
- pallets__flask-4045
- pallets__flask-4992

Not admitted: psf__requests-1963. Two PASS_TO_PASS controls fail on the
reference.

Harness corrections are listed in `HARNESS-CORRECTIONS.txt`. Admission
summary: `admission/summary.json` (SWE-bench spec source v4.1.0, commit
726c5461).
