"""Model-free review of the Stage B natural-task pilot (paper Section V, Table III).

Run from the unpacked artifact, with any Python 3.9+ and no third-party packages:

    python3 -I -B review_stage_b.py            # check and print Table III
    python3 -I -B review_stage_b.py --json out.json

What it does:
1. Verifies every hash recorded in SEAL.json and SEAL-02..05.json.
2. For each task, recomputes Table III directly from the raw receipts:
   - native events;
   - executed-source logs;
   - the source-hash poll;
   - the two grading logs.
   It uses the sealed classifiers (observer_lib v1, observer_classify_v2).
3. Compares each recomputed value with the analysis.json written at run time.
4. Lists every command that names a path outside the task repository, for
   the manual exposure audit (EXPOSURE-AUDIT-ALL.md).

It starts no model, builds no environment and runs no task code. The exit
status is non-zero if a seal or a recomputed value disagrees.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import observer_lib as ol  # noqa: E402  (sealed, SEAL.json)
import observer_classify_v2 as v2  # noqa: E402  (sealed, SEAL-02.json)

TASKS = ['psf__requests-3362', 'pallets__flask-4045', 'pallets__flask-4992']
SEALS = ['SEAL.json', 'SEAL-02.json', 'SEAL-03.json', 'SEAL-04.json', 'SEAL-05.json']
# Same pattern as analyze_task.py (sealed).
TESTLIKE = re.compile(r'(\bpytest\b|\bpy\.test\b|\bunittest\b|\btox\b|\bnox\b|python[\d.]*\s+(-\S+\s+)*\S*test)')
ABS_PATH = re.compile(r'(?<![\w.])(/(?:Users|private|tmp|var|opt|home)/[^\s\'";|&)]*)')


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def parse_pytest_rA(text):
    """Same rule as admission.parse_pytest_rA (sealed)."""
    status = {}
    for line in text.splitlines():
        m = re.match(r'^(PASSED|FAILED|ERROR|XFAIL|XPASS|SKIPPED)\s+(\S+)', line)
        if m:
            status[m.group(2)] = m.group(1)
    return status


def check_seals():
    rows, ok = [], True
    for seal in SEALS:
        files = json.loads((ROOT / seal).read_text())['files']
        for rel, want in files.items():
            p = ROOT / rel
            got = sha256(p) if p.exists() else None
            rows.append({'seal': seal, 'file': rel, 'match': got == want})
            ok &= got == want
    return ok, rows


def review_task(iid):
    run = ROOT / 'runs' / iid
    res = json.loads((run / 'result.json').read_text())
    A = json.loads((run / 'analysis.json').read_text())
    events = [json.loads(l) for l in (run / 'observable-events.jsonl').read_text().splitlines() if l.strip()]
    cmds = []
    for e in events:
        it = (e.get('params') or {}).get('item') or {}
        if e.get('method') == 'item/completed' and it.get('type') in ('commandExecution', 'command_execution'):
            cmds.append({'t': e['t'] - res['model_session_start'], 'command': it.get('command') or '',
                         'exit': it.get('exitCode')})

    tl = ol.load_fs_timeline(run / 'fs-events.jsonl')
    s0, s1 = res['model_session_start'], res['model_session_end']
    procs = [p for p in ol.load_origin_logs(run / 'origin-logs') if s0 <= p['start'] <= s1]
    repo, site = res['repo'], res.get('env_site_packages')
    c1 = [ol.classify_process(p, tl, repo, env_site=site) for p in procs]
    c2 = [v2.classify_process(p, tl, repo, env_site=site) for p in procs]

    adm = json.loads((ROOT / 'admission' / iid / 'record.json').read_text())
    pkg = adm['repo'].split('/')[1].lower()
    installed = ((site or '/nonexistent').rstrip('/') + '/' + pkg + '/').lower()

    f2p = json.loads((ROOT / 'oracle' / iid / 'FAIL_TO_PASS.json').read_text())
    p2p = json.loads((ROOT / 'oracle' / iid / 'PASS_TO_PASS.json').read_text())
    grading = []
    for i in range(2):
        st = parse_pytest_rA((run / 'grading' / f'tests-{i}.txt').read_text())
        grading.append({'F2P': {t: st.get(t, 'MISSING') for t in f2p},
                        'P2P_failed': [t for t in p2p if st.get(t) != 'PASSED']})
    resolved = [all(v == 'PASSED' for v in g['F2P'].values()) and not g['P2P_failed'] for g in grading]

    row = {
        'completion_verdict': res.get('completion_verdict'),
        'milestones': res.get('milestone_statuses'),
        'native_commands': len(cmds),
        'python_processes': len(procs),
        'test_processes': sum(bool(TESTLIKE.search(' '.join(p['argv']))) for p in procs),
        'alive_during_source_write': sum(any(ol.changed_between(tl, f, p['start'], p['end']) for f in tl)
                                         for p in procs),
        'temporal_mismatch_v2': sum(c['temporal_mismatch'] for c in c2),
        'origin_mismatch_v2': sum(c['origin_mismatch'] for c in c2),
        'boundary_ambiguous_v2': sum(bool(c['boundary_ambiguous']) for c in c2),
        'temporal_mismatch_v1': sum(c['temporal_mismatch'] for c in c1),
        'installed_copy_executed': sum(any(r['path'].lower().startswith(installed) for r in p['reads'])
                                       for p in procs),
        'recheck_differs': sum([x['exit'] for x in r['as_run']] != [x['exit'] for x in r['source_forced']]
                               for r in A['recheck']),
        'resolved_each_grading': resolved,
        'f2p_failed': sorted({t for g in grading for t, v in g['F2P'].items() if v != 'PASSED'}),
        'p2p_regressions': max(len(g['P2P_failed']) for g in grading),
    }
    recorded = {
        'native_commands': A['native_commands'],
        'python_processes': A['python_processes'],
        'test_processes': A['test_processes'],
        'alive_during_source_write': A['temporal_opportunities'],
        'temporal_mismatch_v2': len(A['temporal_mismatch_processes']),
        'origin_mismatch_v2': len(A['origin_mismatch_processes']),
        'boundary_ambiguous_v2': len(A.get('boundary_ambiguous_processes', [])),
        'temporal_mismatch_v1': A['v1_comparison']['temporal_mismatch_processes'],
        'installed_copy_executed': A['processes_loading_installed_copy'],
        'resolved_each_grading': [all(v == 'PASSED' for v in g['F2P'].values()) and not g['P2P_failed']
                                  for g in A['grading']],
    }
    mismatches = {k: (row[k], v) for k, v in recorded.items() if row[k] != v}
    outside = []
    for c in cmds:
        for path in ABS_PATH.findall(c['command']):
            if not path.startswith(repo):
                outside.append({'t': round(c['t'], 1), 'exit': c['exit'], 'path': path})
    row['commands_naming_outside_paths'] = outside
    return row, mismatches


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--json', help='write the full review to this file')
    args = ap.parse_args()
    seals_ok, seal_rows = check_seals()
    print(f'seals: {sum(r["match"] for r in seal_rows)}/{len(seal_rows)} file hashes match')
    report, all_ok = {'seals_ok': seals_ok, 'seals': seal_rows, 'tasks': {}}, seals_ok
    for iid in TASKS:
        row, mism = review_task(iid)
        report['tasks'][iid] = {'recomputed': row, 'disagreements_with_analysis_json': mism}
        all_ok &= not mism
    T = report['tasks']
    lines = [
        ('Session verdict', lambda r: r['completion_verdict']),
        ('Native commands', lambda r: r['native_commands']),
        ('Python / test processes', lambda r: f"{r['python_processes']} / {r['test_processes']}"),
        ('Processes alive during a source write', lambda r: r['alive_during_source_write']),
        ('Temporal / origin mismatches (v2)', lambda r: f"{r['temporal_mismatch_v2']} / {r['origin_mismatch_v2']}"),
        ('Boundary-ambiguous (v2)', lambda r: r['boundary_ambiguous_v2']),
        ('Temporal mismatches (v1, superseded)', lambda r: r['temporal_mismatch_v1']),
        ('Installed copy executed', lambda r: r['installed_copy_executed']),
        ('Source-forced recheck differs', lambda r: r['recheck_differs']),
        ('Hidden tests resolved (2 gradings)', lambda r: '/'.join('yes' if x else 'no' for x in r['resolved_each_grading'])),
        ('Pass-to-pass regressions', lambda r: r['p2p_regressions']),
        ('Commands naming outside paths', lambda r: len(r['commands_naming_outside_paths'])),
    ]
    print(f"\n{'':40s}" + ''.join(f'{i.split("__")[1]:>22s}' for i in TASKS))
    for name, f in lines:
        print(f'{name:40s}' + ''.join(f'{str(f(T[i]["recomputed"])):>22s}' for i in TASKS))
    for iid in TASKS:
        r = T[iid]['recomputed']
        print(f'\n{iid}: failing hidden tests: {", ".join(r["f2p_failed"]) or "none"}')
        for o in r['commands_naming_outside_paths']:
            print(f"  outside path at t={o['t']}s (exit {o['exit']}): {o['path']}")
        if T[iid]['disagreements_with_analysis_json']:
            print(f'  DISAGREES with analysis.json: {T[iid]["disagreements_with_analysis_json"]}')
    print('\nOutside paths are for the manual exposure audit; see EXPOSURE-AUDIT-ALL.md for the verdicts.')
    report['status'] = 'pass' if all_ok else 'fail'
    print(f"\nstatus: {report['status']}")
    if args.json:
        Path(args.json).write_text(json.dumps(report, indent=2))
    sys.exit(0 if all_ok else 1)


if __name__ == '__main__':
    main()
