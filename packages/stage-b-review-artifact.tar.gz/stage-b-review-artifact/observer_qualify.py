"""Stage B observer qualification on separate controls (no model, no benchmark task).

Controls, classified only by observer_lib.classify_process:
  T+  a process imports src while a writer replaces it mid-run  -> temporal mismatch
  T-  the writer finishes before the process starts               -> no mismatch
  O+  installed copy in site-packages, repository edited, copy run -> origin mismatch
  O-  same environment, repository copy imported                  -> no mismatch
  P+  stale timestamp pyc (source edited, mtime/size restored? no: header kept)
      is not constructed; pyc writing is disabled in Stage B runs (see DECLARATION).
  SB  one O+ process under the Codex sandbox (workspace-write semantics) to prove
      the recorder can write its log from inside the sandbox.
Qualifies only if every control is classified as expected and SB produced a log.

Run with a base interpreter that has venv+pip+setuptools (macOS: /usr/bin/python3):
  /usr/bin/python3 observer_qualify.py
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import observer_lib as ol  # noqa: E402

CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
WRAPPER = HERE / 'qualification' / 'native_wrapper.py'

PKG_V1 = 'def value():\n    return 1\n'
PKG_V2 = 'def value():\n    return 2\n'
SLOW = 'import time\nimport demo_pkg.core as c\ntime.sleep(1.2)\nprint(c.value())\n'
FAST = 'import demo_pkg.core as c\nprint(c.value())\n'


def setup(root, base_python):
    repo = root / 'repo'
    (repo / 'demo_pkg').mkdir(parents=True)
    (repo / 'demo_pkg' / '__init__.py').write_text('')
    (repo / 'demo_pkg' / 'core.py').write_text(PKG_V1)
    (repo / 'setup.py').write_text("from setuptools import setup\nsetup(name='demo_pkg', version='0', packages=['demo_pkg'])\n")
    (repo / 'slow_check.py').write_text(SLOW)
    (repo / 'fast_check.py').write_text(FAST)
    env = root / 'env'
    subprocess.run([base_python, '-m', 'venv', str(env)], check=True)
    py = str(env / 'bin' / 'python')
    site = subprocess.run([py, '-c', "import sysconfig;print(sysconfig.get_paths()['purelib'])"],
                          capture_output=True, text=True, check=True).stdout.strip()
    return repo, py, site


def run_proc(py, args, cwd, logdir, extra_env=None, prefix=()):
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    env.pop('PYTHONPATH', None)
    env.update(extra_env or {})
    before = set(Path(logdir).glob('*.json')) if Path(logdir).exists() else set()
    p = subprocess.run(list(prefix) + [py] + args, cwd=cwd, env=env, capture_output=True, text=True, timeout=60)
    after = set(Path(logdir).glob('*.json')) if Path(logdir).exists() else set()
    new = sorted(after - before)
    return p, [json.loads(x.read_text()) for x in new]


def main():
    base_python = sys.executable
    out_dir = HERE / 'observer-qualification'
    if (out_dir / 'result.json').exists() and json.loads((out_dir / 'result.json').read_text()).get('qualified'):
        print('observer already qualified'); return 0
    out_dir.mkdir(exist_ok=True)
    if (out_dir / 'result.json').exists() and not list(out_dir.glob('result-*.json')):
        (out_dir / 'result.json').rename(out_dir / 'result-1.json')  # first attempt, before numbering
    root = Path(tempfile.mkdtemp(prefix='sbq-'))
    logdir = Path(tempfile.mkdtemp(prefix='sbq-origin-', dir='/tmp'))
    rec = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'base_python': base_python,
           'model_calls': 0, 'controls': {}}
    try:
        repo, py, site = setup(root, base_python)
        rec['hook'] = ol.install_hook(py, [repo, site], logdir)
        poll_log = out_dir / 'fs-events.jsonl'
        if poll_log.exists():
            poll_log.unlink()
        poller = ol.FsPoller(repo, poll_log).start()
        time.sleep(0.3)

        # T+ : writer replaces core.py while the process is running
        def writer():
            time.sleep(0.5)
            (repo / 'demo_pkg' / 'core.py').write_text(PKG_V2)
        import threading
        th = threading.Thread(target=writer); th.start()
        p, logs = run_proc(py, ['slow_check.py'], repo, logdir)
        th.join(); time.sleep(0.3)
        rec['controls']['T+'] = {'stdout': p.stdout.strip(), 'logs': len(logs), 'raw': logs}
        # T- : file already V2 and unchanged during the process
        time.sleep(0.3)
        p, logs = run_proc(py, ['slow_check.py'], repo, logdir)
        time.sleep(0.3)
        rec['controls']['T-'] = {'stdout': p.stdout.strip(), 'logs': len(logs), 'raw': logs}
        # O+ : an installed (non-editable) copy of V2 in site-packages, as `pip install .`
        # leaves it; copied directly so the control needs no network or build backend.
        shutil.copytree(repo / 'demo_pkg', Path(site) / 'demo_pkg')
        time.sleep(0.3)
        (repo / 'demo_pkg' / 'core.py').write_text(PKG_V1)
        time.sleep(0.4)
        elsewhere = Path(tempfile.mkdtemp(prefix='sbq-cwd-'))
        shutil.copy(repo / 'fast_check.py', elsewhere / 'fast_check.py')
        p, logs = run_proc(py, ['fast_check.py'], elsewhere, logdir)
        rec['controls']['O+'] = {'stdout': p.stdout.strip(), 'logs': len(logs), 'raw': logs}
        # O- : same environment, repository copy shadows the installed one (cwd first on sys.path)
        p, logs = run_proc(py, ['fast_check.py'], repo, logdir)
        rec['controls']['O-'] = {'stdout': p.stdout.strip(), 'logs': len(logs), 'raw': logs}
        # SB : the O+ process under the Codex sandbox (writable: cwd and temp dirs)
        # CLI 0.166: `codex sandbox [OPTIONS] [COMMAND]...` runs under seatbelt; an explicit
        # config override requires a named permission profile. Try the forms in order and
        # keep the first that executes. A form only counts if the sandbox is really
        # restrictive: a write outside the writable roots (into this folder) must be denied.
        sb = None
        rec['sandbox_attempts'] = []
        forms = [['sandbox', '-C', str(elsewhere), '--'],
                 ['sandbox', '-P', ':workspace', '-C', str(elsewhere), '--'],
                 ['sandbox', '-P', 'workspace', '-C', str(elsewhere), '--'],
                 ['sandbox', '-P', 'workspace-write', '-C', str(elsewhere), '--']]
        probe_target = out_dir / 'sb-denied-probe.txt'
        for form in (forms if Path(CLI).exists() else []):
            if probe_target.exists():
                probe_target.unlink()
            pr = subprocess.run([CLI] + form + [py, '-c', f'open({str(probe_target)!r}, "w").write("x")'],
                                cwd=elsewhere, capture_output=True, text=True, timeout=60)
            att = {'form': form, 'probe_exit': pr.returncode, 'probe_stderr': pr.stderr[-400:],
                   'outside_write_denied': not probe_target.exists(),
                   'usage_error': 'Usage: codex sandbox' in pr.stderr}
            rec['sandbox_attempts'].append(att)
            if not att['usage_error'] and att['outside_write_denied']:
                sb = form
                break
        if probe_target.exists():
            probe_target.unlink()
        rec['sandbox_subcommand'] = sb
        if sb:
            p, logs = run_proc(py, ['fast_check.py'], elsewhere, logdir, prefix=[CLI] + sb)
            rec['controls']['SB'] = {'stdout': p.stdout.strip(), 'stderr': p.stderr[-500:], 'logs': len(logs), 'raw': logs}
        poller.stop()

        tl = ol.load_fs_timeline(poll_log)
        expect = {'T+': ('temporal_mismatch', True), 'T-': ('temporal_mismatch', False),
                  'O+': ('origin_mismatch', True), 'O-': ('origin_mismatch', False),
                  'SB': ('origin_mismatch', True)}
        ok = True
        for name, (field, want) in expect.items():
            c = rec['controls'].get(name)
            if c is None:
                ok = False; continue
            cls = [ol.classify_process(l, tl, repo, env_site=site) for l in c['raw']]
            c['classified'] = cls
            got = any(x[field] for x in cls) if cls else None
            c['expected'] = {field: want}
            c['pass'] = bool(cls) and got == want
            ok = ok and c['pass']
            c.pop('raw')
        rec['qualified'] = ok
    except Exception as exc:
        import traceback
        rec.update(qualified=False, exception=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc())
    n = len(list(out_dir.glob('result-*.json'))) + 1
    rec['attempt'] = n
    (out_dir / f'result-{n}.json').write_text(json.dumps(rec, indent=2))  # every attempt is kept
    (out_dir / 'result.json').write_text(json.dumps(rec, indent=2))
    print(json.dumps({'qualified': rec.get('qualified'), 'sandbox_subcommand': rec.get('sandbox_subcommand'),
                      'controls': {k: {'pass': v.get('pass'), 'logs': v.get('logs'), 'stdout': v.get('stdout')}
                                   for k, v in rec['controls'].items()},
                      'exception': rec.get('exception')}, indent=2))
    return 0 if rec.get('qualified') else 1


if __name__ == '__main__':
    raise SystemExit(main())
