"""Stage B: one natural task, one attempt, real model (AMENDMENT-01, DECLARATION.md).

  ~/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python -B run_task.py <instance_id>

Before any model call, it refuses to run unless:
  - the seal matches (SEAL.json);
  - A'1 and the observer qualification passed;
  - the task was admitted;
  - the task has never been launched.
It then builds a fresh workspace and environment by the admitted recipe and
records a shell probe. Oracle, admission and cache folders are made
unreadable (chmod 000) for the duration of the model session.
Log-only receipts: native observable events (reasoning dropped), a
filesystem poller and the executed-source recorder. Never retried.
"""
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import observer_lib as ol  # noqa: E402

MEMSRC = Path.home() / ('Documents/ChatGPT/worksop/research-archive/topics/13-execution-window-evidence/'
                        'experiments/01-controlled-discovery/artifacts/memtrace-source/src')
sys.path.insert(0, str(MEMSRC))
WRAPPER = HERE / 'qualification' / 'native_wrapper.py'
CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
MODEL = 'gpt-6.1-sol'
PYTHONS = {'3.9': '/usr/bin/python3', '3.11': '/opt/homebrew/anaconda3/bin/python3.11'}
WORK = Path.home() / 'sbwork'  # neutral location, outside the experiment folder
TURNS, WALL = 8, 900
PROTECT = ['oracle', 'admission', 'cache']
TASK_PREFIX = 'Resolve the following issue in this repository.\n\n'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run(argv, cwd=None, env=None, check=True, timeout=1800):
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    if check and p.returncode != 0:
        raise RuntimeError(f'failed ({p.returncode}): {argv}\n{p.stderr[-3000:]}')
    return p


def check_gates(iid):
    seal = json.loads((HERE / 'SEAL.json').read_text())
    for rel, want in seal['files'].items():
        got = sha(HERE / rel)
        if got != want:
            raise SystemExit(f'seal mismatch for {rel}: {got} != {want}')
    a1 = [json.loads((p / 'result.json').read_text()) for p in sorted((HERE / 'qualification').glob('a1-attempt-*'))
          if (p / 'result.json').exists()]
    if not any(r.get('qualified') for r in a1):
        raise SystemExit('A1 not qualified')
    oq = HERE / 'observer-qualification' / 'result.json'
    if not oq.exists() or not json.loads(oq.read_text()).get('qualified'):
        raise SystemExit('observer not qualified')
    summary = json.loads((HERE / 'admission' / 'summary.json').read_text())
    if iid not in summary['admitted']:
        raise SystemExit(f'{iid} was not admitted')
    prev = HERE / 'runs' / iid
    if prev.exists():
        r = json.loads((prev / 'result.json').read_text()) if (prev / 'result.json').exists() else {}
        if r.get('model_reached', True):
            raise SystemExit(f'{iid} already reached the model (or state unknown); single attempt only')
        # A pre-model setup failure is preserved and the task may be rebuilt from scratch.
        stamp = time.strftime('%Y%m%dT%H%M%S')
        keep = HERE / 'runs' / '_pre-model-failures'; keep.mkdir(parents=True, exist_ok=True)
        prev.rename(keep / f'{iid}-{stamp}')
        if (WORK / iid).exists():
            (WORK / '_pre-model-failures').mkdir(parents=True, exist_ok=True)
            (WORK / iid).rename(WORK / '_pre-model-failures' / f'{iid}-{stamp}')
    elif (WORK / iid).exists():
        raise SystemExit(f'{WORK / iid} exists without a run record; refusing')
    return seal


def build(iid, out, root=None):
    """Fresh workspace + environment by the admitted recipe; history scrubbed like SWE-bench."""
    adm = json.loads((HERE / 'admission' / iid / 'record.json').read_text())
    spec = adm['spec']
    base = adm['base_commit']
    freeze = (HERE / 'admission' / iid / 'pip-freeze.txt').read_text()
    reqs = HERE / 'admission' / iid / 'requirements.txt'
    mirror = HERE / 'cache' / 'repos' / (adm['repo'].replace('/', '__') + '.git')
    root = root or (WORK / iid)
    repo, env_dir = root / 'repo', root / 'env'
    root.mkdir(parents=True)
    log = out / 'setup-log.txt'

    def r(argv, cwd=None, env=None):
        p = run(argv, cwd=cwd, env=env)
        with open(log, 'a') as f:
            f.write(f'$ {argv}\n{p.stdout[-4000:]}{p.stderr[-4000:]}\n')
        return p

    r(['git', 'clone', '-q', '--no-hardlinks', str(mirror), str(repo)])
    r(['git', 'checkout', '-q', '-B', 'main', base], cwd=repo)
    # SWE-bench-style scrub: no remote, no other branches, no tags after the base commit,
    # no reflog; then prove that no commit newer than the base is reachable.
    r(['git', 'remote', 'remove', 'origin'], cwd=repo)
    for b in r(['git', 'for-each-ref', '--format=%(refname)', 'refs/heads', 'refs/remotes'], cwd=repo).stdout.split():
        if b != 'refs/heads/main':
            r(['git', 'update-ref', '-d', b], cwd=repo)
    base_ts = int(r(['git', 'show', '-s', '--format=%ct', base], cwd=repo).stdout.strip())
    for line in r(['git', 'for-each-ref', '--format=%(refname) %(*committerdate:unix)%(committerdate:unix)',
                   'refs/tags'], cwd=repo).stdout.splitlines():
        ref, ts = line.split()[0], int(re.sub(r'\D', '', line.split()[1]) or 0)
        if ts > base_ts:
            r(['git', 'update-ref', '-d', ref], cwd=repo)
    r(['git', 'reflog', 'expire', '--expire=now', '--all'], cwd=repo)
    r(['git', 'gc', '-q', '--prune=now'], cwd=repo)
    newer = r(['git', 'log', '--all', '--format=%H', f'--since={base_ts + 1}'], cwd=repo).stdout.split()
    if newer:
        raise RuntimeError(f'history scrub incomplete: {len(newer)} newer commits reachable')
    future = r(['git', '--git-dir', str(mirror), 'rev-list', '--all', f'--since={base_ts + 1}'],
               cwd=repo).stdout.split()
    probe = subprocess.run(['git', 'cat-file', '--batch-check'], cwd=repo, input='\n'.join(future) + '\n',
                           capture_output=True, text=True)
    present = [l for l in probe.stdout.splitlines() if l and not l.endswith('missing')]
    if present:
        raise RuntimeError(f'{len(present)} future commit objects still present after scrub')
    (out / 'history-scrub.json').write_text(json.dumps({'base_commit': base, 'base_unix': base_ts,
                                                        'future_commits_checked': len(future),
                                                        'future_commits_present': 0}, indent=2))
    if r(['git', 'rev-parse', 'HEAD'], cwd=repo).stdout.strip() != base:
        raise RuntimeError('HEAD is not the base commit')

    py = PYTHONS[str(spec['python'])]
    r([py, '-m', 'venv', str(env_dir)])
    env = {**os.environ, 'VIRTUAL_ENV': str(env_dir), 'PATH': f"{env_dir}/bin:{os.environ['PATH']}",
           'PIP_DISABLE_PIP_VERSION_CHECK': '1'}
    env.pop('PYTHONPATH', None)
    vpy = str(env_dir / 'bin' / 'python')
    # Constrain every install to the admitted versions (admission pip freeze).
    cons = root / 'constraints.txt'
    cons.write_text('\n'.join(l for l in freeze.splitlines() if '==' in l and not l.startswith('-e')) + '\n')
    r([vpy, '-m', 'pip', 'install', '-q', '--upgrade', 'pip'], env=env)
    if spec.get('packages') == 'requirements.txt':
        if adm.get('setup_correction'):
            pin = re.search(r'pyyaml==([\d.]+)', adm['setup_correction'], flags=re.I).group(1)
            r([vpy, '-m', 'pip', 'install', '-q', 'cython<3', 'wheel', 'setuptools<70'], env=env)
            r([vpy, '-m', 'pip', 'install', '-q', '--no-build-isolation', f'pyyaml=={pin}'], env=env)
        r([vpy, '-m', 'pip', 'install', '-q', '-c', str(cons), '-r', str(reqs)], env=env)
    elif spec.get('packages'):
        r([vpy, '-m', 'pip', 'install', '-q', '-c', str(cons)] + shlex.split(spec['packages']), env=env)
    if spec.get('pip_packages'):
        r([vpy, '-m', 'pip', 'install', '-q', '-c', str(cons)] + list(spec['pip_packages']), env=env)
    r(['bash', '-c', spec['install']], cwd=repo, env=env)
    new_freeze = r([vpy, '-m', 'pip', 'freeze'], env=env).stdout
    norm = lambda t: sorted(l for l in t.splitlines() if '==' in l and not l.lower().startswith(('-e', 'requests==', 'flask==')))
    if norm(new_freeze) != norm(freeze):
        (out / 'freeze-diff.txt').write_text('\n'.join(sorted(set(norm(new_freeze)) ^ set(norm(freeze)))))
        raise RuntimeError('environment differs from the admitted freeze (see freeze-diff.txt)')
    (out / 'pip-freeze-start.txt').write_text(new_freeze)
    status = r(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=repo).stdout
    (out / 'git-status-after-install.txt').write_text(status)
    return adm, repo, env_dir, env


def shell_probe(repo, env_dir, env, out):
    """What an ordinary login shell in the workspace resolves (no model involved)."""
    p = run(['/bin/zsh', '-lc', 'command -v python python3 pytest; python -c "import sys;print(sys.prefix)"'],
            cwd=repo, env=env, check=False)
    lines = p.stdout.split()
    probe = {'stdout': p.stdout, 'stderr': p.stderr[-1000:], 'exit': p.returncode}
    probe['python_in_env'] = bool(lines) and lines[0].startswith(str(env_dir))
    probe['pytest_in_env'] = any(l.endswith('/pytest') and l.startswith(str(env_dir)) for l in lines)
    probe['sys_prefix_is_env'] = str(env_dir) in p.stdout.splitlines()[-1] if p.stdout else False
    (out / 'shell-probe.json').write_text(json.dumps(probe, indent=2))
    if not (probe['python_in_env'] and probe['pytest_in_env'] and probe['sys_prefix_is_env']):
        raise RuntimeError('login shell does not resolve the task environment (see shell-probe.json); '
                           'pre-model setup failure')
    return probe


def main():
    iid = sys.argv[1]
    seal = check_gates(iid)
    out = HERE / 'runs' / iid
    out.mkdir(parents=True)
    rec = {'instance_id': iid, 'utc_start': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
           'model': MODEL, 'reasoning_effort': 'medium', 'sandbox_mode': 'workspace-write',
           'learned_planning': True, 'budget': {'execution_turns': TURNS, 'wall_seconds': WALL},
           'seal_sha256': sha(HERE / 'SEAL.json'), 'cli_sha256': sha(CLI), 'stage': 'setup',
           'model_reached': False, 'provider_turn_requests': 0, 'native_commands': 0, 'model_usage': []}
    observable, protected, transport, poller = [], [], None, None
    origin_dir = Path('/tmp') / f'sb-origin-{iid}-{int(time.time())}'
    started = time.monotonic()
    try:
        adm, repo, env_dir, env = build(iid, out)
        site = run([str(env_dir / 'bin' / 'python'), '-c',
                    "import sysconfig;print(sysconfig.get_paths()['purelib'])"]).stdout.strip()
        rec['env_site_packages'] = site
        rec['hook'] = ol.install_hook(str(env_dir / 'bin' / 'python'), [repo, site], origin_dir)
        rec['shell_probe'] = shell_probe(repo, env_dir, env, out)
        problem = (HERE / 'tasks' / iid / 'problem_statement.md').read_text()
        task = TASK_PREFIX + problem
        (out / 'user_task.txt').write_text(task)
        rec['user_task_sha256'] = hashlib.sha256(task.encode()).hexdigest()
        rec['repo'], rec['env'] = str(repo), str(env_dir)

        from memtrace.contracts import primitive
        from memtrace.harness.adapter import CodexHarnessAdapter
        from memtrace.harness.transport import SubprocessJsonlTransport
        from memtrace.harness.schema import CodexProtocolSchemaProbe
        from memtrace.harness.revision import WorkspaceRevisionTracker
        from memtrace.config import V2RuntimeConfig, RunBudgetConfiguration
        from memtrace.orchestration.models import RunRequest
        from memtrace.orchestration.run_coordinator import RunCoordinator

        class RecordedTransport(SubprocessJsonlTransport):
            def _send(self, value):
                if value.get('method') == 'turn/start':
                    rec['provider_turn_requests'] += 1
                    rec['model_reached'] = True
                return super()._send(value)

            @staticmethod
            def _read_stdout(process, incoming):
                try:
                    for line in process.stdout:
                        if not line.strip():
                            continue
                        value = json.loads(line)
                        method = value.get('method', ''); params = value.get('params', {})
                        typ = (params.get('item') or {}).get('type', '')
                        if 'reasoning' not in method.lower() and 'reasoning' not in typ.lower() \
                                and 'delta' not in method.lower():
                            observable.append({'t': time.time(), **value})
                            if method == 'item/completed' and typ in ('commandExecution', 'command_execution'):
                                rec['native_commands'] += 1
                            if method == 'thread/tokenUsage/updated':
                                rec['model_usage'].append(params)
                        incoming.put(value)
                except BaseException as exc:
                    incoming.put(exc)
                finally:
                    incoming.put(None)

        runtime = out / 'runtime'; runtime.mkdir()
        schema = CodexProtocolSchemaProbe(str(WRAPPER), timeout_seconds=60).probe()
        (out / 'schema-receipt.json').write_text(json.dumps(primitive(schema), indent=2))
        app_env = {**env}
        for key in ['OPENAI_API_KEY', 'CODEX_API_KEY', 'OPENAI_BASE_URL']:
            app_env.pop(key, None)
        app_env['CODEX_SQLITE_HOME'] = str(out / 'native-state')
        revision = WorkspaceRevisionTracker.compute(repo, runtime)
        rec['base_revision_id'] = revision

        # Protect oracle/admission/cache for the model session.
        for name in PROTECT:
            p = HERE / name
            protected.append((p, p.stat().st_mode & 0o7777))
            os.chmod(p, 0)
        poller = ol.FsPoller(repo, out / 'fs-events.jsonl').start()
        time.sleep(0.5)

        def expired(*_):
            raise TimeoutError('task watchdog expired')
        signal.signal(signal.SIGALRM, expired)
        signal.alarm(WALL + 120)
        transport = RecordedTransport(executable=str(WRAPPER), cwd=repo, timeout_seconds=300, environment=app_env,
                                      extra_args=('-c', 'sqlite_home=' + json.dumps(str(out / 'native-state'))))
        adapter = CodexHarnessAdapter(repository_path=repo, model=MODEL, run_root=runtime, transport=transport,
                                      executable=str(WRAPPER), reasoning_effort='medium',
                                      sandbox_mode='workspace-write')
        adapter.protocol_schema = schema
        request = RunRequest(repository_path=repo, repository_id='stageb-' + iid, run_id='stageb-' + iid,
                             branch_id='main', revision_id=revision, user_task=task, plan=None, actions=(),
                             run_root=runtime)
        config = V2RuntimeConfig(run_budget=RunBudgetConfiguration(max_execution_turns=TURNS,
                                                                   wall_clock_seconds=WALL))
        rec['stage'] = 'model-session'
        rec['model_session_start'] = time.time()
        try:
            returned = primitive(RunCoordinator(config).run(request, harness_adapter=adapter))
            (out / 'returned.json').write_text(json.dumps(returned, indent=2, default=str))
            for k in ('completion_verdict', 'task_status', 'milestone_statuses', 'unmet_completion_criteria',
                      'unmet_final_criteria', 'unverified_final_criteria', 'failed_tests', 'route_stalls'):
                rec[k] = returned.get(k)
        except BaseException as exc:
            rec.update(session_exception_type=type(exc).__name__, session_exception=str(exc)[:3000])
            (out / 'session-exception.txt').write_text(traceback.format_exc())
        finally:
            signal.alarm(0)
            rec['model_session_end'] = time.time()
            try:
                st = transport.request('mcpServerStatus/list', {})
                rec['mcp_server_status_after_run'] = {str(s.get('name')): len(s.get('tools') or {})
                                                      for s in (st.get('data') or []) if isinstance(s, dict)}
            except Exception as exc:
                rec['mcp_status_error'] = str(exc)[:500]
        rec['stage'] = 'freeze'
        time.sleep(0.5)
        poller.stop(); poller = None
        # Frozen final state: diff against base (tracked + untracked), snapshot, environment.
        run(['git', 'add', '-A', '-N'], cwd=repo, check=False)
        (out / 'final.patch').write_text(run(['git', 'diff', '--binary', adm['base_commit']], cwd=repo).stdout)
        run(['tar', '-czf', str(out / 'final-snapshot.tar.gz'), '--exclude', '.git', '-C', str(repo), '.'])
        (out / 'pip-freeze-end.txt').write_text(run([str(env_dir / 'bin' / 'python'), '-m', 'pip', 'freeze'],
                                                    env=env).stdout)
        rec['stage'] = 'complete'
    except BaseException as exc:
        rec.update(run_exception_type=type(exc).__name__, run_exception=str(exc)[:3000])
        (out / 'exception.txt').write_text(traceback.format_exc())
    finally:
        if poller is not None:
            poller.stop()
        for p, mode in protected:
            try:
                os.chmod(p, mode)
            except Exception:
                pass
        if transport is not None:
            rec['native_stderr_tail'] = list(transport._stderr)[-20:]
            try:
                transport.close()
            except Exception:
                pass
        if origin_dir.exists():
            shutil.copytree(origin_dir, out / 'origin-logs', dirs_exist_ok=True)
        rec['origin_log_count'] = len(list((out / 'origin-logs').glob('*.json'))) if (out / 'origin-logs').exists() else 0
        rec['seconds'] = time.monotonic() - started
        rec['utc_end'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        (out / 'observable-events.jsonl').write_text(''.join(json.dumps(e, default=str) + '\n' for e in observable))
        (out / 'result.json').write_text(json.dumps(rec, indent=2, default=str))
    print(json.dumps({k: rec.get(k) for k in ('instance_id', 'stage', 'model_reached', 'provider_turn_requests',
                                              'native_commands', 'completion_verdict', 'task_status',
                                              'origin_log_count', 'seconds', 'run_exception',
                                              'session_exception')}, indent=2, default=str))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
