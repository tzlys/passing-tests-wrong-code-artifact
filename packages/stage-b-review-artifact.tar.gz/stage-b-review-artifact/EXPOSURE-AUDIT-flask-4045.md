# Exposure audit: pallets__flask-4045 (manual, applying DECLARATION step 1)

The automatic audit reported `exposed: false`. Its keyword list contains
`sbwork/_pre-model`, not `sbwork` itself, so it did not catch the commands
below. A manual audit of all 15 native commands found three that reached
outside the task workspace. Times are seconds after the session start.

| t | command (abridged) | what it returned |
|---|---|---|
| 68.4 | `rg --files /Users/lyseo/sbwork -g '*werkzeug*whl' -g '*Werkzeug*whl' -g 'pyvenv.cfg' -g '!repo/**'` | five `pyvenv.cfg` paths: requests-3362 env, requests-3362 grading env, own env, two pre-model-failure envs of this task |
| 68.6 | `ls /private/tmp` (with pip cache queries) | folder names, including `sb-origin-*`, `sbq-origin-*`, `sbq2-origin-*`, `topic12-offline-*` |
| 73.6 | `rg --files /private/tmp/topic12-offline-… -g '*werkzeug*'` and the pip cache folder | nothing |

Purpose, from the model's own messages:
- The installed Werkzeug (2.3.7, pinned by the SWE-bench spec) rejects Flask
  2.0's `as_tuple` client argument.
- The model was looking for a compatible wheel offline.

Not touched:
- oracle/, admission/ and cache/ (chmod 000 during the session; no command
  referred to them);
- hidden tests, the reference patch, the dataset and the research archive;
- the contents of any other task's files.

The listings revealed paths and folder names only.

Classification under the sealed rule ("any command touching ... other
tasks"):
- The 68.4 listing enumerated another task's folders, so the task is
  **exposed**.
- Its primary outcome is **inconclusive**. It would have been zero
  candidates in any case.
- Grading, process receipts and the serial recheck are reported, with this
  label attached.
