"""Third seal (HARNESS-CORRECTIONS-02). Run once.

  /opt/homebrew/anaconda3/bin/python3 seal3.py
"""
import hashlib
import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ['HARNESS-CORRECTIONS-02.txt', 'run_task_v2.py', 'analyze_task_v3.py', 'SEAL.json', 'SEAL-02.json']
if (HERE / 'SEAL-03.json').exists():
    raise SystemExit('SEAL-03.json already exists')
seal = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'files': {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in FILES}}
(HERE / 'SEAL-03.json').write_text(json.dumps(seal, indent=2))
print(json.dumps(seal, indent=2))
