"""Second seal (ANALYSIS-CORRECTION-01): run once, after classifier_v2_qualify passes.

  /opt/homebrew/anaconda3/bin/python3 seal2.py
"""
import hashlib
import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ['ANALYSIS-CORRECTION-01.md', 'observer_classify_v2.py', 'classifier_v2_qualify.py',
         'analyze_task_v2.py', 'observer-qualification-v2/result.json', 'SEAL.json']

if (HERE / 'SEAL-02.json').exists():
    raise SystemExit('SEAL-02.json already exists')
if not json.loads((HERE / 'observer-qualification-v2' / 'result.json').read_text()).get('qualified'):
    raise SystemExit('classifier v2 not qualified')
seal = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'files': {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in FILES}}
(HERE / 'SEAL-02.json').write_text(json.dumps(seal, indent=2))
print(json.dumps(seal, indent=2))
