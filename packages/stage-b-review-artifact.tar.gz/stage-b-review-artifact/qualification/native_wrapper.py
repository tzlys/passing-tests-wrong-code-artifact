#!/Users/lyseo/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python
"""Configuration-only launcher, unchanged from the October qualification.

Uses existing local ChatGPT authentication; never reads, copies or logs tokens.
It reads only the *names* of configured MCP servers from config.toml in order to
disable them (values are not read into logs).
"""
import os
import sys
import json
from pathlib import Path
import re
import tomllib

CLI='/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
args=[CLI]
configuration=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'config.toml'
if configuration.is_file():
    with configuration.open('rb') as stream:settings=tomllib.load(stream)
    for name in sorted(settings.get('mcp_servers',{})):
        # A0 correction (2026-11-14): the CLI splits -c keys on '.', so a JSON-quoted
        # segment created a new server literally named '"node_repl"' with no transport.
        # Bare TOML keys address the existing entry; quoting is kept only when required.
        key=name if re.fullmatch(r'[A-Za-z0-9_-]+',name) else json.dumps(name)
        args.extend(['-c','mcp_servers.'+key+'.enabled=false'])
for feature in ['apps','plugins','multi_agent','multi_agent_v2','browser_use',
                'browser_use_external','computer_use','image_generation',
                'skill_search','memories','workspace_dependencies','view_image',
                'goals','sleep_tool','hooks']:
    args.extend(['--disable',feature])
args.extend(['--enable','skip_host_skill_discovery',
             '-c','model_provider="openai"',
             '-c','web_search="disabled"','-c','project_doc_max_bytes=0',
             '-c','model_reasoning_summary="none"'])
args.extend(sys.argv[1:])
env=os.environ.copy()
for key in ['OPENAI_API_KEY','CODEX_API_KEY','OPENAI_BASE_URL']:
    env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
os.execve(CLI,args,env)
