from subject import value
assert value() == 1
