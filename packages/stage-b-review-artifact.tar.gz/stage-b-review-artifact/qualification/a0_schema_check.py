"""Stage A'0: zero-inference compatibility check of the installed Codex CLI.

No thread is started and no turn is sent, so no model inference happens.
Saves the App Server schema, MemTrace's schema receipt, the initialize
handshake result and (if the method exists) the list of model ids.
At most two attempts (one pre-model launcher correction, AMENDMENT-01).

Run with the MemTrace runtime:
  ~/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python -B a0_schema_check.py
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
MEMSRC = Path.home() / ('Documents/ChatGPT/worksop/research-archive/topics/13-execution-window-evidence/'
                        'experiments/01-controlled-discovery/artifacts/memtrace-source/src')
sys.path.insert(0, str(MEMSRC))
CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
WRAPPER = HERE / 'native_wrapper.py'
MODEL = 'gpt-6.1-sol'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    attempts = sorted(HERE.glob('a0-attempt-*'))
    if any(json.loads((a / 'result.json').read_text()).get('qualified') for a in attempts if (a / 'result.json').exists()):
        print('A0 already qualified; nothing to do.'); return 0
    if len(attempts) >= 2:
        print('A0 attempt limit (2) reached; Stage B stops per AMENDMENT-01.'); return 1
    out = HERE / f'a0-attempt-{len(attempts) + 1}'
    out.mkdir()
    rec = {'stage': 'A0', 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
           'model_inference': False, 'thread_started': False,
           'cli_version': subprocess.run([CLI, '--version'], capture_output=True, text=True).stdout.strip(),
           'cli_sha256': sha(CLI), 'wrapper_sha256': sha(WRAPPER),
           'amendment_sha256': sha(STAGE / 'AMENDMENT-01.md'), 'python': sys.version.split()[0]}
    transport = None
    try:
        os.chmod(WRAPPER, 0o755)
        # 1. installed schema through the same launcher (keeps the files)
        g = subprocess.run([str(WRAPPER), 'app-server', 'generate-json-schema', '--experimental',
                            '--out', str(out / 'schema')], capture_output=True, text=True, timeout=60)
        rec['generate_schema_exit'] = g.returncode
        rec['generate_schema_stderr_tail'] = g.stderr[-2000:]
        if g.returncode != 0:
            raise RuntimeError('schema generation through launcher failed')
        client = (out / 'schema' / 'ClientRequest.json').read_text()
        rec['client_request_methods_present'] = {m: f'"{m}"' in client for m in
                                                 ['model/list', 'thread/start', 'turn/start', 'turn/interrupt',
                                                  'thread/inject_items', 'thread/compact/start']}
        # 2. MemTrace's own probe
        from memtrace.contracts import primitive
        from memtrace.harness.schema import CodexProtocolSchemaProbe
        schema = CodexProtocolSchemaProbe(str(WRAPPER), timeout_seconds=60).probe()
        rec['memtrace_schema_receipt'] = primitive(schema)
        # 3. initialize handshake only
        from memtrace.harness.adapter import CodexHarnessAdapter
        from memtrace.harness.transport import SubprocessJsonlTransport
        fixture = Path(tempfile.mkdtemp(prefix='a0-fixture-'))
        env = os.environ.copy()
        for key in ['OPENAI_API_KEY', 'CODEX_API_KEY', 'OPENAI_BASE_URL']:
            env.pop(key, None)
        env['CODEX_SQLITE_HOME'] = str(out / 'native-state')
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        transport = SubprocessJsonlTransport(executable=str(WRAPPER), cwd=fixture, timeout_seconds=60,
                                             environment=env,
                                             extra_args=('-c', 'sqlite_home=' + json.dumps(str(out / 'native-state'))))
        adapter = CodexHarnessAdapter(repository_path=fixture, model=MODEL, run_root=out / 'runtime',
                                      transport=transport, executable=str(WRAPPER),
                                      reasoning_effort='medium', sandbox_mode='workspace-write')
        adapter.protocol_schema = schema
        adapter.initialize()
        rec['initialize_ok'] = True
        if rec['client_request_methods_present']['model/list']:
            resp = transport.request('model/list', {})
            items = resp.get('data') or resp.get('models') or resp.get('items') or []
            rec['model_ids'] = sorted({str(i.get('id') or i.get('model') or i) for i in items if isinstance(i, dict)})
            rec['model_listed'] = MODEL in rec['model_ids']
        # Confirm that every configured MCP server is disabled (names and status only).
        status = transport.request('mcpServerStatus/list', {})
        servers = status.get('data') or status.get('servers') or []
        def runtime(s):
            r = s.get('runtimeStatus')
            return r.get('status') if isinstance(r, dict) else r
        rec['mcp_server_status'] = {str(s.get('name')): {'runtimeStatus': runtime(s),
                                                         'tool_count': len(s.get('tools') or {})}
                                    for s in servers if isinstance(s, dict)}
        rec['mcp_all_disabled'] = all(v['runtimeStatus'] in ('disabled', 'notStarted', None)
                                      and v['tool_count'] == 0
                                      for v in rec['mcp_server_status'].values())
        rec['qualified'] = bool(rec['initialize_ok'] and rec.get('model_listed', True)
                                and rec.get('mcp_all_disabled', False))
    except Exception as exc:
        rec.update(qualified=False, exception_type=type(exc).__name__, exception=str(exc)[:3000])
        (out / 'exception.txt').write_text(traceback.format_exc())
    finally:
        if transport is not None:
            rec['native_stderr_tail'] = list(transport._stderr)[-12:]
            transport.close()
        (out / 'result.json').write_text(json.dumps(rec, indent=2))
    print(json.dumps({k: v for k, v in rec.items() if k not in ('memtrace_schema_receipt', 'native_stderr_tail',
                                                                  'generate_schema_stderr_tail')}, indent=2))
    return 0 if rec.get('qualified') else 1


if __name__ == '__main__':
    raise SystemExit(main())
