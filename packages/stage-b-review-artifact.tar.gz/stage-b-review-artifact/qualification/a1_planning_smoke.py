"""Stage A'1: the single model-bearing re-qualification (AMENDMENT-01).

Benign fixture with an already passing assertion; learned planning
(RunRequest.plan = None); gpt-6.1-sol, medium effort, workspace-write,
local ChatGPT auth. Exactly one attempt: refuses to run if a1/ exists.
Saves observable actions, verdicts and usage; reasoning content is dropped.

Run with the MemTrace runtime, only after A0 qualified:
  ~/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python -B a1_planning_smoke.py
"""
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
MEMSRC = Path.home() / ('Documents/ChatGPT/worksop/research-archive/topics/13-execution-window-evidence/'
                        'experiments/01-controlled-discovery/artifacts/memtrace-source/src')
sys.path.insert(0, str(MEMSRC))
WRAPPER = HERE / 'native_wrapper.py'
CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
MODEL = 'gpt-6.1-sol'
WATCHDOG = 300


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p, v):
    Path(p).write_text(json.dumps(v, indent=2, default=str) + '\n')


def main():
    a0 = [a for a in sorted(HERE.glob('a0-attempt-*'))
          if (a / 'result.json').exists() and json.loads((a / 'result.json').read_text()).get('qualified')]
    if not a0:
        print('A0 has not qualified; A1 is not allowed.'); return 1
    prior = sorted(HERE.glob('a1-attempt-*'))
    a0_used_correction = len(sorted(HERE.glob('a0-attempt-*'))) > 1
    for p in prior:
        r = json.loads((p / 'result.json').read_text()) if (p / 'result.json').exists() else {}
        if r.get('provider_turn_requests', 1) > 0 or r.get('qualified'):
            print(f'{p.name} already reached the model or qualified; no further A1 attempt.'); return 1
    if len(prior) >= 2 or (prior and a0_used_correction):
        print('The single pre-model correction allowance is used; Stage B stops.'); return 1
    out = HERE / f'a1-attempt-{len(prior) + 1}'
    out.mkdir()

    def expired(*_):
        raise TimeoutError(f'{WATCHDOG}-second smoke watchdog expired')
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(WATCHDOG)

    from memtrace.contracts import primitive
    from memtrace.harness.adapter import CodexHarnessAdapter
    from memtrace.harness.transport import SubprocessJsonlTransport
    from memtrace.harness.schema import CodexProtocolSchemaProbe
    from memtrace.harness.revision import WorkspaceRevisionTracker
    from memtrace.config import V2RuntimeConfig, RunBudgetConfiguration
    from memtrace.orchestration.models import RunRequest
    from memtrace.orchestration.run_coordinator import RunCoordinator

    work = out / 'workspace'; work.mkdir()
    subject = 'def value():\n    return 1\n'
    test = 'from subject import value\nassert value() == 1\n'
    (work / 'subject.py').write_text(subject)
    (work / 'test_subject.py').write_text(test)
    runtime = out / 'runtime'; runtime.mkdir()
    task = ('Run the existing test_subject.py using the available Python interpreter. '
            'Do not edit either source file. Report the actual result.')
    rec = {'stage': 'start', 'kind': 'benign learned-planning re-qualification (A1)',
           'scientific_pilot_started': False, 'model': MODEL, 'reasoning_effort': 'medium',
           'sandbox_mode': 'workspace-write', 'learned_planning': True, 'supplied_plan': None,
           'user_task': task, 'provider_turn_requests': 0, 'native_commands': 0, 'model_usage': [],
           'cli_sha256': sha(CLI), 'wrapper_sha256': sha(WRAPPER), 'script_sha256': sha(__file__),
           'amendment_sha256': sha(STAGE / 'AMENDMENT-01.md'), 'a0_attempt': a0[-1].name,
           'credentials_created_or_exported': False, 'new_cloud_spend': 0}
    observable = []
    transport = None
    started = time.monotonic()

    class RecordedTransport(SubprocessJsonlTransport):
        def _send(self, value):
            if value.get('method') == 'turn/start':
                rec['provider_turn_requests'] += 1
            return super()._send(value)

        @staticmethod
        def _read_stdout(process, incoming):
            try:
                for line in process.stdout:
                    if not line.strip():
                        continue
                    value = json.loads(line)
                    method = value.get('method', ''); params = value.get('params', {})
                    typ = (params.get('item') or {}).get('type', '')
                    if 'reasoning' not in method.lower() and 'reasoning' not in typ.lower():
                        if method in ['item/started', 'item/completed', 'turn/started', 'turn/completed',
                                      'turn/plan/updated', 'error', 'thread/tokenUsage/updated']:
                            observable.append({'t': time.time(), **value})
                            if method == 'item/completed' and typ in ['commandExecution', 'command_execution']:
                                rec['native_commands'] += 1
                            if method == 'thread/tokenUsage/updated':
                                rec['model_usage'].append(params)
                    incoming.put(value)
            except BaseException as exc:
                incoming.put(exc)
            finally:
                incoming.put(None)

    try:
        rec['stage'] = 'repository-preparation'
        for argv in [['git', 'init', '-q'], ['git', 'add', 'subject.py', 'test_subject.py'],
                     ['git', '-c', 'user.name=Research Fixture', '-c', 'user.email=fixture@example.invalid',
                      '-c', 'commit.gpgsign=false', '-c', 'core.hooksPath=/dev/null', 'commit', '-qm', 'Benign fixture']]:
            subprocess.run(argv, cwd=work, check=True, capture_output=True, text=True)
        rec['stage'] = 'schema'
        schema = CodexProtocolSchemaProbe(str(WRAPPER), timeout_seconds=60).probe()
        write(out / 'schema-receipt.json', primitive(schema))
        env = os.environ.copy()
        for key in ['OPENAI_API_KEY', 'CODEX_API_KEY', 'OPENAI_BASE_URL']:
            env.pop(key, None)
        env['CODEX_SQLITE_HOME'] = str(out / 'native-state')
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        transport = RecordedTransport(executable=str(WRAPPER), cwd=work, timeout_seconds=120, environment=env,
                                      extra_args=('-c', 'sqlite_home=' + json.dumps(str(out / 'native-state'))))
        adapter = CodexHarnessAdapter(repository_path=work, model=MODEL, run_root=runtime, transport=transport,
                                      executable=str(WRAPPER), reasoning_effort='medium',
                                      sandbox_mode='workspace-write')
        adapter.protocol_schema = schema
        request = RunRequest(repository_path=work, repository_id='benign-requalification',
                             run_id='natural-requalification-a1', branch_id='main',
                             revision_id=WorkspaceRevisionTracker.compute(work, runtime),
                             user_task=task, plan=None, actions=(), run_root=runtime)
        rec['stage'] = 'real-model-planning-and-execution'
        config = V2RuntimeConfig(run_budget=RunBudgetConfiguration(max_execution_turns=2,
                                                                   wall_clock_seconds=WATCHDOG - 30))
        returned = primitive(RunCoordinator(config).run(request, harness_adapter=adapter))
        write(out / 'returned.json', returned)
        rec['completion_verdict'] = returned.get('completion_verdict')
        rec['task_status'] = returned.get('task_status')
        rec['milestone_statuses'] = returned.get('milestone_statuses')
        rec['unmet_completion_criteria'] = returned.get('unmet_completion_criteria')
        plan_events = [e for e in returned.get('trace', []) if isinstance(e, dict)
                       and 'PLAN_GENERATED' in json.dumps(e)]
        rec['plan_trace_events'] = plan_events
        rec['projected_milestones'] = len(returned.get('milestone_statuses') or {})
        rec['stage'] = 'fresh-assertion'
        fresh = subprocess.run([sys.executable, '-B', 'test_subject.py'], cwd=work,
                               env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                               capture_output=True, text=True, timeout=10)
        rec['fresh_assertion_exit'] = fresh.returncode
        rec['fixture_unchanged'] = ((work / 'subject.py').read_text() == subject
                                    and (work / 'test_subject.py').read_text() == test)
        # MCP must stay off in the live session (names, status and tool counts only).
        status = transport.request('mcpServerStatus/list', {})
        def runtime(s):
            r = s.get('runtimeStatus')
            return r.get('status') if isinstance(r, dict) else r
        rec['mcp_server_status_after_run'] = {str(s.get('name')): {'runtimeStatus': runtime(s),
                                              'tool_count': len(s.get('tools') or {})}
                                              for s in (status.get('data') or []) if isinstance(s, dict)}
        rec['mcp_tool_call_items'] = sum(1 for e in observable
                                         if 'mcp' in str(((e.get('params') or {}).get('item') or {}).get('type', '')).lower())
        rec['mcp_off'] = (rec['mcp_tool_call_items'] == 0 and all(
            v['tool_count'] == 0 and v['runtimeStatus'] in ('disabled', 'notStarted', None)
            for v in rec['mcp_server_status_after_run'].values()))
        rec['qualified'] = (rec['mcp_off'] and rec['projected_milestones'] >= 1 and rec['native_commands'] > 0
                            and rec['completion_verdict'] == 'COMPLETED'
                            and fresh.returncode == 0 and rec['fixture_unchanged'])
        rec['stage'] = 'complete'
    except BaseException as exc:
        rec.update(qualified=False, exception_type=type(exc).__name__, exception=str(exc)[:3000])
        (out / 'exception.txt').write_text(traceback.format_exc())
    finally:
        signal.alarm(0)
        if transport is not None:
            rec['native_stderr_tail'] = list(transport._stderr)[-12:]
            transport.close()
        rec['seconds'] = time.monotonic() - started
        (out / 'observable-events.jsonl').write_text(''.join(json.dumps(e, default=str) + '\n' for e in observable))
        write(out / 'result.json', rec)
    print(json.dumps({k: v for k, v in rec.items()
                      if k not in ('native_stderr_tail', 'model_usage', 'plan_trace_events')}, indent=2, default=str))
    return 0 if rec.get('qualified') else 1


if __name__ == '__main__':
    raise SystemExit(main())
