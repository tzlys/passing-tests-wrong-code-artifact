"""analyze_task.py with the corrected classifier (ANALYSIS-CORRECTION-01).

Runs the sealed analyze_task.main unchanged except that process classification
uses observer_classify_v2; the v1 classification is added for comparison.

  ~/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python -B analyze_task_v2.py <instance_id>
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import observer_lib as ol  # noqa: E402
import observer_classify_v2 as v2  # noqa: E402
import analyze_task  # noqa: E402

V1 = ol.classify_process


def main():
    seal2 = json.loads((HERE / 'SEAL-02.json').read_text())
    import hashlib
    for rel, want in seal2['files'].items():
        if hashlib.sha256((HERE / rel).read_bytes()).hexdigest() != want:
            raise SystemExit(f'SEAL-02 mismatch for {rel}')
    iid = sys.argv[1]
    ol.classify_process = v2.classify_process
    analyze_task.main()
    ol.classify_process = V1
    out = HERE / 'runs' / iid
    A = json.loads((out / 'analysis.json').read_text())
    res = json.loads((out / 'result.json').read_text())
    tl = ol.load_fs_timeline(out / 'fs-events.jsonl')
    logs = ol.load_origin_logs(out / 'origin-logs') if (out / 'origin-logs').exists() else []
    s0, s1 = res.get('model_session_start', 0), res.get('model_session_end', 1e18)
    procs = [p for p in logs if s0 <= p['start'] <= s1]
    c1 = [V1(p, tl, res['repo'], env_site=res.get('env_site_packages')) for p in procs]
    c2 = [v2.classify_process(p, tl, res['repo'], env_site=res.get('env_site_packages')) for p in procs]
    A['classifier'] = 'v2 (ANALYSIS-CORRECTION-01)'
    A['v1_comparison'] = {'temporal_mismatch_processes': sum(c['temporal_mismatch'] for c in c1),
                          'origin_mismatch_processes': sum(c['origin_mismatch'] for c in c1),
                          'v1_only_temporal_pids': [a['pid'] for a, b in zip(c1, c2)
                                                    if a['temporal_mismatch'] and not b['temporal_mismatch']]}
    A['boundary_ambiguous_processes'] = [c for c in c2 if c['boundary_ambiguous']]
    (out / 'analysis.json').write_text(json.dumps(A, indent=2, default=str))
    print(json.dumps({'classifier': A['classifier'], 'v1_comparison': A['v1_comparison'],
                      'boundary_ambiguous_processes': len(A['boundary_ambiguous_processes'])}, indent=2))


if __name__ == '__main__':
    main()
