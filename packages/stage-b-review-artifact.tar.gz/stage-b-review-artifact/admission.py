"""Stage B task admission (no model calls).

For each of the four sealed pilot tasks this script:
  1. reads only the needed columns of the sealed SWE-bench Lite parquet
     (sha256 7a21f37b...) and stores the reference patch / hidden tests in
     oracle/<id>/ -- never in a model workspace;
  2. reads the official environment spec from a fresh clone of the SWE-bench
     harness (commit recorded), instead of a hand-written recipe;
  3. builds a fresh checkout + virtualenv at the base commit by that recipe;
  4. applies the developer tests and checks that FAIL_TO_PASS really fails;
  5. applies the reference patch and checks that FAIL_TO_PASS now passes
     (PASS_TO_PASS is recorded, not gated);
  6. writes admission/<id>/record.json and a summary.

A task is ADMITTED only if every FAIL_TO_PASS test fails on base+tests and
passes on base+tests+reference. Nothing is retried for quality. Run with the
anaconda Python 3.11 (needs pandas + pyarrow):
    /opt/homebrew/anaconda3/bin/python3 admission.py
"""
import hashlib
import importlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARQUET = Path.home() / 'Documents/ChatGPT/worksop/topic-search/2026-10-17-flaky-feedback/sources/swebench-lite-test.parquet'
PARQUET_SHA = '7a21f37b8bc179c7db5beeb14e88ac538ba283455c776e6b2535bbfb6e3551b4'
PILOT = ['psf__requests-1963', 'psf__requests-3362', 'pallets__flask-4045', 'pallets__flask-4992']
SEALED_BASE = {  # from the sealed selection.json (sha256 2b2cb1c7...)
    'psf__requests-1963': '110048f9837f8441ea536804115e80b69f400277',
    'psf__requests-3362': '36453b95b13079296776d11b09cab2567ea3e703',
    'pallets__flask-4045': 'd8c37f43724cd9fb0870f77877b7c4c7e38a19e0',
    'pallets__flask-4992': '4c288bc97ea371817199908d0d9b12de9dae327e',
}
PYTHONS = {'3.9': '/usr/bin/python3', '3.11': '/opt/homebrew/anaconda3/bin/python3.11'}
COLUMNS = ['instance_id', 'repo', 'base_commit', 'version', 'environment_setup_commit',
           'problem_statement', 'patch', 'test_patch', 'FAIL_TO_PASS', 'PASS_TO_PASS']

ORACLE = HERE / 'oracle'
ADMIT = HERE / 'admission'
CACHE = HERE / 'cache'
LOGS = ADMIT / 'logs'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(argv, cwd=None, env=None, log=None, timeout=1800, check=True):
    """Run a command, append full output to a log file, return CompletedProcess."""
    started = time.time()
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    if log is not None:
        with open(log, 'a') as f:
            f.write(f'\n$ {" ".join(map(str, argv)) if isinstance(argv, list) else argv}\n')
            f.write(f'# cwd={cwd} exit={p.returncode} seconds={time.time() - started:.1f}\n')
            f.write(p.stdout)
            f.write(p.stderr)
    if check and p.returncode != 0:
        raise RuntimeError(f'command failed ({p.returncode}): {argv}\n{p.stderr[-2000:]}')
    return p


def load_rows():
    import pyarrow.parquet as pq
    assert sha(PARQUET) == PARQUET_SHA, 'parquet hash changed'
    table = pq.read_table(PARQUET, columns=COLUMNS)
    rows = {r['instance_id']: r for r in table.to_pylist() if r['instance_id'] in PILOT}
    assert set(rows) == set(PILOT), f'missing rows: {set(PILOT) - set(rows)}'
    for k, base in SEALED_BASE.items():
        assert rows[k]['base_commit'] == base, f'base commit mismatch for {k}'
    return rows


def load_swebench_specs(log):
    """Read MAP_REPO_VERSION_TO_SPECS from the newest official SWE-bench release that has it.

    SWE-bench 5.x replaced the per-repo/version spec table with pre-generated Docker
    images, so the table is taken from the most recent release tag that still ships
    it. Tag and commit are recorded.
    """
    dest = CACHE / 'SWE-bench'
    if not dest.exists():
        run(['git', 'clone', '--depth', '1', 'https://github.com/SWE-bench/SWE-bench.git', str(dest)], log=log)
    head = run(['git', 'rev-parse', 'HEAD'], cwd=dest, log=log).stdout.strip()
    refs = run(['git', 'ls-remote', '--tags', 'origin'], cwd=dest, log=log).stdout.split('\n')
    tags = sorted({m.group(1) for line in refs
                   for m in [re.search(r'refs/tags/(v?\d+(?:\.\d+)*)$', line.strip())] if m},
                  key=lambda t: tuple(int(x) for x in t.lstrip('v').split('.')), reverse=True)
    chosen = None
    for tag in tags:
        run(['git', 'fetch', '-q', '--depth', '1', 'origin', f'refs/tags/{tag}:refs/tags/{tag}'],
            cwd=dest, log=log, check=False)
        shown = run(['git', 'show', f'{tag}:swebench/harness/constants/__init__.py'],
                    cwd=dest, log=log, check=False)
        if shown.returncode == 0 and 'MAP_REPO_VERSION_TO_SPECS' in shown.stdout:
            chosen = tag
            break
    if chosen is None:
        raise RuntimeError('no SWE-bench release tag with MAP_REPO_VERSION_TO_SPECS found')
    commit = run(['git', 'rev-list', '-n', '1', chosen], cwd=dest, log=log).stdout.strip()
    legacy = CACHE / f'SWE-bench-{chosen}'
    if not legacy.exists():
        legacy.mkdir(parents=True)
        run(['bash', '-c', f'git archive {shlex.quote(chosen)} swebench | tar -x -C {shlex.quote(str(legacy))}'],
            cwd=dest, log=log)
    # Stub the top-level packages so that their __init__ (docker, datasets, ...) is not executed.
    for name, sub in [('swebench', 'swebench'), ('swebench.harness', 'swebench/harness')]:
        mod = types.ModuleType(name)
        mod.__path__ = [str(legacy / sub)]
        sys.modules[name] = mod
    constants = importlib.import_module('swebench.harness.constants')
    specs = constants.MAP_REPO_VERSION_TO_SPECS
    global REQS_PATHS, NON_TEST_EXTS
    REQS_PATHS = dict(constants.MAP_REPO_TO_REQS_PATHS)
    NON_TEST_EXTS = list(constants.NON_TEST_EXTS)
    return {'release_tag': chosen, 'tag_commit': commit, 'main_head_checked': head}, specs


REQS_PATHS = {}
NON_TEST_EXTS = []
# Harness corrections (documented in diagnostics/HARNESS-CORRECTIONS.txt). A task listed
# here gets exactly one rebuild; its first record is preserved under diagnostics/.
HARNESS_RERUN = {
    'pallets__flask-4992': 'v1 passed a non-test data file (.toml) to pytest; SWE-bench filters NON_TEST_EXTS',
    'pallets__flask-4045': 'pinned PyYAML 5.4.1 has no macOS-arm64/py3.9 wheel and its sdist fails under Cython 3',
}
REPLACE_REQ_PACKAGES = [('types-pkg_resources', 'types-setuptools')]  # as in SWE-bench v4.1.0


def requirements_text(mirror, repo, commit, log):
    """Faithful port of SWE-bench v4.1.0 get_requirements_by_commit + clean_requirements.

    The official code fetches raw.githubusercontent.com/<repo>/<commit>/<path>; the same
    bytes are read here with `git show <commit>:<path>` from the local mirror.
    """
    def show(path):
        p = run(['git', '--git-dir', str(mirror), 'show', f'{commit}:{path}'], log=log, check=False)
        return p.stdout if p.returncode == 0 else None
    for req_path in REQS_PATHS[repo]:
        text = show(req_path)
        if text is not None:
            break
    else:
        raise RuntimeError(f'no requirements file at {REQS_PATHS[repo]} for {repo}@{commit}')
    exclude = lambda line: any(line.strip().startswith(x) for x in ['-e .', '#', '.[test'])
    req_dir = '/'.join(req_path.split('/')[:-1])
    original, additional = [], []
    for line in text.split('\n'):
        if line.strip().startswith('-r'):
            extra = show(os.path.join(req_dir, line[len('-r'):].strip()))
            if extra is not None:
                additional += [x for x in extra.split('\n') if not exclude(x)]
        elif not exclude(line):
            original.append(line)
    additional.append('\n'.join(original))
    out = '\n'.join(additional)
    for old, new in REPLACE_REQ_PACKAGES:
        out = re.sub(rf'^{re.escape(old)}([<>=!~]=?.*|$)', new, out, flags=re.M)
    return out


def test_files_from_patch(test_patch):
    """Port of SWE-bench v4.1.0 get_test_directives for pytest repos."""
    files = re.findall(r'^diff --git a/.* b/(.*)$', test_patch, flags=re.M)
    return [f for f in dict.fromkeys(files) if not any(f.endswith(e) for e in NON_TEST_EXTS)]


def protocol_admission(rec):
    """Sealed PROTOCOL.txt: a fresh base must fail a named bug assertion behaviorally;
    the reference must pass that assertion and the fixed regression controls (PASS_TO_PASS).
    Collection errors (ERROR/MISSING) and skips never count."""
    base, ref = rec['base']['F2P'], rec['reference']['F2P']
    named = [t for t in base if base[t] == 'FAILED' and ref.get(t) == 'PASSED']
    controls_ok = all(v == 'PASSED' for v in rec['reference']['P2P'].values())
    return {'named_bug_assertions': named, 'regression_controls_all_pass': controls_ok,
            'admitted': bool(named) and controls_ok}


def parse_pytest_rA(text):
    """Map test id -> status from `pytest -rA` short summary lines."""
    status = {}
    for line in text.splitlines():
        m = re.match(r'^(PASSED|FAILED|ERROR|XFAIL|XPASS|SKIPPED)\s+(\S+)', line)
        if m:
            status[m.group(2)] = m.group(1)
    return status


def outcome(ids, status):
    return {t: status.get(t, 'MISSING') for t in ids}


def main():
    for d in (ORACLE, ADMIT, CACHE, LOGS):
        d.mkdir(parents=True, exist_ok=True)
    glog = LOGS / 'global.txt'
    rows = load_rows()
    swe_commit, specs = load_swebench_specs(glog)
    summary = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
               'parquet_sha256': PARQUET_SHA, 'swebench_spec_source': swe_commit,
               'model_calls': 0, 'tasks': {}}

    for iid in PILOT:
        row = rows[iid]
        (ADMIT / iid).mkdir(parents=True, exist_ok=True)
        done = ADMIT / iid / 'record.json'
        kept = ADMIT / 'diagnostics' / f'{iid}.record-v1.json'
        if done.exists() and iid in HARNESS_RERUN and not kept.exists():
            kept.parent.mkdir(parents=True, exist_ok=True)
            done.rename(kept)  # preserved; this is the one allowed harness rebuild
            if (LOGS / f'{iid}.txt').exists():
                (LOGS / f'{iid}.txt').rename(ADMIT / 'diagnostics' / f'{iid}.log-v1.txt')
        if done.exists():  # recorded outcomes are final; no re-run
            rec = json.loads(done.read_text())
            summary['tasks'][iid] = {k: rec.get(k) for k in
                                     ('admitted', 'version', 'python', 'base_f2p_all_fail',
                                      'reference_f2p_all_pass', 'reference_p2p_passed', 'p2p_total', 'error')}
            summary['tasks'][iid]['reused_existing_record'] = True
            if 'base' in rec:
                rec['protocol'] = protocol_admission(rec)
                rec['admitted_initial_script_rule'] = rec.get('admitted_initial_script_rule', rec.get('admitted'))
                rec['admitted'] = rec['protocol']['admitted']
                done.write_text(json.dumps(rec, indent=2))
                summary['tasks'][iid].update(admitted=rec['admitted'], protocol=rec['protocol'])
            print(iid, '(existing record)', json.dumps(summary['tasks'][iid]), flush=True)
            continue
        log = LOGS / f'{iid}.txt'
        log.write_text('')
        rec = {'instance_id': iid, 'repo': row['repo'], 'base_commit': row['base_commit'],
               'version': row['version'], 'environment_setup_commit': row['environment_setup_commit']}
        try:
            # --- oracle material, kept out of any model workspace
            od = ORACLE / iid
            od.mkdir(parents=True, exist_ok=True)
            (od / 'patch.diff').write_text(row['patch'])
            (od / 'test_patch.diff').write_text(row['test_patch'])
            f2p, p2p = json.loads(row['FAIL_TO_PASS']), json.loads(row['PASS_TO_PASS'])
            (od / 'FAIL_TO_PASS.json').write_text(json.dumps(f2p, indent=2))
            (od / 'PASS_TO_PASS.json').write_text(json.dumps(p2p, indent=2))
            (HERE / 'tasks' / iid).mkdir(parents=True, exist_ok=True)
            (HERE / 'tasks' / iid / 'problem_statement.md').write_text(row['problem_statement'])

            spec = specs[row['repo']][row['version']]
            rec['spec'] = {k: v for k, v in spec.items() if isinstance(v, (str, list, dict, int, float, bool))}
            py = PYTHONS.get(str(spec.get('python')))
            if py is None:
                raise RuntimeError(f"no local interpreter for python {spec.get('python')}")
            for bad in ('pre_install', 'eval_commands'):
                if spec.get(bad):
                    rec[f'{bad}_present'] = True  # recorded; reviewed below
            if spec.get('packages') == 'environment.yml':
                raise RuntimeError('spec uses environment.yml; not handled, needs review')

            # --- source checkout
            mirror = CACHE / 'repos' / (row['repo'].replace('/', '__') + '.git')
            if not mirror.exists():
                run(['git', 'clone', '--mirror', f"https://github.com/{row['repo']}.git", str(mirror)], log=log)
            work = ADMIT / iid / 'repo'
            if work.exists():
                shutil.rmtree(work)
            run(['git', 'clone', '-q', str(mirror), str(work)], log=log)
            run(['git', 'checkout', '-q', row['base_commit']], cwd=work, log=log)

            # --- environment by the official recipe
            venv = ADMIT / iid / 'venv'
            if venv.exists():
                shutil.rmtree(venv)
            run([py, '-m', 'venv', str(venv)], log=log)
            env = {**os.environ, 'VIRTUAL_ENV': str(venv), 'PATH': f"{venv}/bin:{os.environ['PATH']}",
                   'PIP_DISABLE_PIP_VERSION_CHECK': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
            env.pop('PYTHONPATH', None)
            vpy = str(venv / 'bin/python')
            run([vpy, '-m', 'pip', 'install', '-q', '--upgrade', 'pip'], env=env, log=log)
            if spec.get('packages') == 'requirements.txt':
                reqs = requirements_text(mirror, row['repo'], row['environment_setup_commit'], log)
                (ADMIT / iid / 'requirements.txt').write_text(reqs)
                pin = re.search(r'^(?i:pyyaml)==(5\.[\d.]+)\s*$', reqs, flags=re.M)
                if pin and iid in HARNESS_RERUN:
                    # Same pinned version; build it with Cython<3 because no wheel exists here.
                    run([vpy, '-m', 'pip', 'install', '-q', 'cython<3', 'wheel', 'setuptools<70'], env=env, log=log)
                    run([vpy, '-m', 'pip', 'install', '-q', '--no-build-isolation', f'pyyaml=={pin.group(1)}'],
                        env=env, log=log)
                    rec['setup_correction'] = f'pyyaml=={pin.group(1)} built with cython<3, --no-build-isolation'
                run([vpy, '-m', 'pip', 'install', '-q', '-r', str(ADMIT / iid / 'requirements.txt')], env=env, log=log)
            elif spec.get('packages'):
                run([vpy, '-m', 'pip', 'install', '-q'] + shlex.split(spec['packages']), env=env, log=log)
            if spec.get('pip_packages'):
                run([vpy, '-m', 'pip', 'install', '-q'] + list(spec['pip_packages']), env=env, log=log)
            for cmd in spec.get('pre_install', []) or []:
                if re.search(r'apt-get|apt |sudo', cmd):
                    rec.setdefault('skipped_pre_install', []).append(cmd)
                    continue
                run(['bash', '-c', cmd], cwd=work, env=env, log=log)
            run(['bash', '-c', spec['install']], cwd=work, env=env, log=log)
            freeze = run([vpy, '-m', 'pip', 'freeze'], env=env, log=log).stdout
            (ADMIT / iid / 'pip-freeze.txt').write_text(freeze)
            rec['python'] = run([vpy, '--version'], env=env, log=log).stdout.strip()

            test_cmd = spec['test_cmd'] if isinstance(spec['test_cmd'], str) else ' '.join(spec['test_cmd'])
            files = test_files_from_patch(row['test_patch'])
            rec['test_cmd'] = test_cmd
            rec['test_files'] = files

            def run_tests(label):
                p = run(['bash', '-c', f"{test_cmd} {' '.join(shlex.quote(f) for f in files)}"],
                        cwd=work, env=env, log=log, timeout=1800, check=False)
                (ADMIT / iid / f'tests-{label}.txt').write_text(p.stdout + p.stderr)
                st = parse_pytest_rA(p.stdout)
                return {'exit': p.returncode, 'F2P': outcome(f2p, st), 'P2P': outcome(p2p, st)}

            # --- base + developer tests: F2P must fail
            (ADMIT / iid / 'test_patch.diff').write_text(row['test_patch'])
            run(['git', 'apply', str(ADMIT / iid / 'test_patch.diff')], cwd=work, log=log)
            base = run_tests('base')
            # --- base + tests + reference patch: F2P must pass
            (ADMIT / iid / 'patch.diff').write_text(row['patch'])
            run(['git', 'apply', str(ADMIT / iid / 'patch.diff')], cwd=work, log=log)
            gold = run_tests('reference')
            run(['git', 'checkout', '-q', '--', '.'], cwd=work, log=log)
            run(['git', 'clean', '-qfdx', '-e', 'venv'], cwd=work, log=log)
            (ADMIT / iid / 'patch.diff').unlink()
            (ADMIT / iid / 'test_patch.diff').unlink()

            # A new test that cannot even be collected on base (import error etc.) shows up as
            # MISSING; like the SWE-bench grader we count it as failing, but only when the
            # base test run itself exited non-zero.
            fail_states = ('FAILED', 'ERROR') + (('MISSING',) if base['exit'] != 0 else ())
            base_fail = all(v in fail_states for v in base['F2P'].values())
            gold_pass = all(v == 'PASSED' for v in gold['F2P'].values())
            rec.update(base=base, reference=gold, base_f2p_all_fail=base_fail,
                       reference_f2p_all_pass=gold_pass,
                       reference_p2p_passed=sum(v == 'PASSED' for v in gold['P2P'].values()),
                       p2p_total=len(p2p),
                       admitted_initial_script_rule=bool(base_fail and gold_pass and f2p))
            rec['protocol'] = protocol_admission(rec)
            rec['admitted'] = rec['protocol']['admitted']
            if iid in HARNESS_RERUN:
                rec['harness_correction'] = HARNESS_RERUN[iid]
        except Exception as exc:  # recorded, never retried for quality
            rec.update(admitted=False, error=f'{type(exc).__name__}: {exc}'[:3000])
        (ADMIT / iid / 'record.json').write_text(json.dumps(rec, indent=2))
        summary['tasks'][iid] = {k: rec.get(k) for k in
                                 ('admitted', 'version', 'python', 'base_f2p_all_fail',
                                  'reference_f2p_all_pass', 'reference_p2p_passed', 'p2p_total', 'error',
                                  'protocol', 'setup_correction', 'harness_correction')}
        print(iid, json.dumps(summary['tasks'][iid]), flush=True)

    summary['oracle_sha256'] = {str(p.relative_to(HERE)): sha(p) for p in sorted(ORACLE.rglob('*')) if p.is_file()}
    summary['admitted'] = [k for k, v in summary['tasks'].items() if v['admitted']]
    summary['pilot_may_proceed'] = len(summary['admitted']) >= 3
    (ADMIT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print('\nadmitted:', summary['admitted'], '| pilot may proceed (>=3):', summary['pilot_may_proceed'])


if __name__ == '__main__':
    main()
