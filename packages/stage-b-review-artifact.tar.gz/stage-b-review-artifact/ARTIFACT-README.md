# Stage B natural-task pilot: review artifact

This artifact supports Section V and Table III of "When Passing Tests Support
the Wrong Code". It holds the sealed protocol, every correction, and the raw
receipts and grading logs of the three admitted SWE-bench Lite tasks:
psf__requests-3362, pallets__flask-4045 and pallets__flask-4992.

## Check it (about one second, standard library only)

    python3 -I -B review_stage_b.py

The script:
- verifies every hash in SEAL.json and SEAL-02..05.json;
- recomputes Table III from the raw receipts with the sealed classifiers;
- compares each value with the analysis.json written at run time;
- lists every command that names a path outside the task repository.

It prints `status: pass` when everything agrees. It starts no model, builds
no environment and runs no task code.

## Read in this order

1. DECLARATION.md, AMENDMENT-01.md, AMENDMENT-02.md: what was fixed before
   any task reached the model. The original protocol, PROTOCOL.txt, is
   referenced by hash in SEAL.json.
2. HARNESS-CORRECTIONS*.txt and ANALYSIS-CORRECTION-01.md: every later
   change, why it was made, and when relative to the model runs.
3. RESULTS-PILOT.md, EXPOSURE-AUDIT-ALL.md and EXPOSURE-AUDIT-flask-4045.md:
   the outcome and the manual exposure audit.
4. runs/<task>/:
   - observable-events.jsonl: native Codex events;
   - origin-logs/: which source files each Python process opened, and when;
   - fs-events.jsonl: repository source hashes, polled every 0.1 s;
   - grading/tests-*.txt: the two held-out gradings;
   - analysis.json: the analysis written at run time;
   - final.patch and final-snapshot.tar.gz: the model's final tree;
   - runtime/: MemTrace's evidence store.
5. runs/_pre-model-failures/: setup failures that never reached the model.

## What is not included

- Codex native state, credentials and the CLI binary.
- Admission repository and virtualenv copies, and the clone cache.
- `account/*` and `remoteControl/*` notifications, which concern the
  operator's account rather than the task. They were dropped from every
  .jsonl file without being inspected; MANIFEST.json lists the counts.
  The review does not use them.

## What cannot be redone from this artifact

- **The model sessions.** They used gpt-6.1-sol through Codex CLI
  0.166.0-alpha.5.1 on macOS ARM and cannot be replayed.
- **Grading from scratch.** That needs the environment recipes in
  admission.py and network access.
- **Linux regrading.** The model-free regrading with the official
  containerized harness (AMENDMENT-02) is not yet included.
