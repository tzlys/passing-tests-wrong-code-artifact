# Stage B natural-task pilot: results (3 admitted tasks)

Written 2026-11-15 ~18:30 America/New_York, after all three pilot tasks were
run and graded.

Setup:
- Codex CLI 0.166.0-alpha.5.1, gpt-6.1-sol, medium effort.
- MemTrace learned planning (AMENDMENT-01).
- One attempt per task. No retries.

## Primary outcome

**0 confirmed primary cases in 3 tasks.** No task produced a candidate.

| | requests-3362 | flask-4045 | flask-4992 |
|---|---|---|---|
| MemTrace verdict | COMPLETED (M001 COMPLETED_VERIFIED) | same | same |
| Hidden-test resolved (2 gradings) | no, stable | no, stable | no, stable |
| P2P regressions | 0 | 0 | 0 |
| Native commands / Python processes / test processes | 16 / 10 / 8 | 15 / 9 / 6 | 18 / 14 / 7 |
| Processes with a source edit during their lifetime | 2 | 1 | 0 |
| Temporal mismatch (v2) | 0 | 0 | 0 |
| Executable-origin mismatch | 0 | 0 | 0 |
| Boundary-ambiguous | 0 | 0 | 0 |
| v1-only temporal (classifier artifact) | 1 (pid 6294) | 0 | 0 |
| Processes loading the installed copy | 0 | 0 | 0 |
| Test-like commands whose source-forced recheck differs from the run | 0 | 0 | 0 |
| Exposure audit | clean | **exposed → primary inconclusive** | clean |
| Session (s) / turn requests / total tokens | 123 / 4 / 0.66 M | 135 / 5 / 0.75 M | 158 / 5 / 1.13 M |

Recheck rows with exit 127 are non-test `rg` commands that the recheck
environment cannot run. They are not counted as test-like.

Continuation gate (PROTOCOL):
- Expansion requires at least 1 confirmed primary case.
- None was found, so pytest-5221, pytest-7490, pylint-7993 and pylint-5859 are
  **not run**.
- The pilot is closed.

## Secondary observation: wrong code accepted for a different reason

All three tasks were accepted by the agent's own criteria and failed a hidden
fail-to-pass test. In every case the agent's own tests passed on the code as
it actually ran.

The gap is between the issue text and the hidden test. It is not about which
code ran:

- **requests-3362:** for encoding None, the agent kept bytes and asserted
  bytes. The hidden test expects str, decoded via `apparent_encoding`.
- **flask-4045:** the issue asks for a ValueError on dotted blueprint names.
  The agent did exactly that, and that hidden test passes. The reference fix
  also converts the endpoint-dot `assert` into a ValueError, which the issue
  does not mention. The test `test_route_decorator_custom_endpoint_with_dots`
  fails.
- **flask-4992:** the issue proposes `mode="b"`. The agent implemented
  `mode`. The merged fix and the hidden test use `text=False`, so the test
  fails with TypeError.

These are specification gaps of the kind already documented for SWE-bench.
They are reported as context only, not as evidence for the
execution-window mechanism.

## Grading validity

- Admission ran each reference patch through the same SWE-bench procedure:
  - every F2P passed;
  - every P2P passed.
- Grading on the model patch:
  - applied the patch cleanly;
  - left all P2P passing;
  - gave the same result twice.
- Each failure log shows a concrete assertion or TypeError tied to the
  difference described above.
- Model-free re-grading on Linux with the official Docker harness is planned
  under AMENDMENT-02.

## Why the mechanism did not show up here (observations, not tests)

- The pytest runs imported the repository's own source (`src/` or package
  root) in every run. The installed copy was never executed.
- Edits and test runs alternated. Codex did not edit while its own test
  processes were alive, except in 3 processes, and none of those had a
  mismatch.
- The launcher's `PYTHONDONTWRITEBYTECODE=1` closes the stale-bytecode route.
- Native command timestamps are coarse. Process-level timing came from the
  audit-hook recorder.

## Disclosed corrections

- **HARNESS-CORRECTIONS 01–04:**
  - admission rule;
  - toml directive;
  - pinned constraints;
  - freeze comment;
  - hiding other tasks during the session.
  All were made before the model ran on the affected task, except 04. 04 was
  triggered by the flask-4045 exposure and applied to flask-4992 only.
- **ANALYSIS-CORRECTION-01:** classifier v2. It was data-triggered by a v1
  false positive on requests-3362 and qualified on synthetic controls before
  use. v1 results are reported alongside.
- **AMENDMENT-01:** learned planning and CLI re-qualification.
- **AMENDMENT-02:** Linux re-grading.
