"""Fifth seal (HARNESS-CORRECTIONS-04). Run once.

  /opt/homebrew/anaconda3/bin/python3 seal5.py
"""
import hashlib
import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ['HARNESS-CORRECTIONS-04.txt', 'run_task_v4.py', 'EXPOSURE-AUDIT-flask-4045.md', 'SEAL.json', 'SEAL-02.json', 'SEAL-03.json', 'SEAL-04.json']
if (HERE / 'SEAL-05.json').exists():
    raise SystemExit('SEAL-05.json already exists')
seal = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'files': {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in FILES}}
(HERE / 'SEAL-05.json').write_text(json.dumps(seal, indent=2))
print(json.dumps(seal, indent=2))
