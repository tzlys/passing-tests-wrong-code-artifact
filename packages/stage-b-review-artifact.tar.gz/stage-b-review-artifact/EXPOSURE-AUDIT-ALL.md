# Exposure audit: all three pilot tasks (manual)

## Rule

A command "touches another task" if its output reveals any content or path
belonging to another task, to the oracle, or to observer logs.

Commands that only test for `AGENTS.md` files and return nothing are
Codex's standard instruction lookup. They do not count.

## Commands that reached outside the workspace

| task | t (s) | command | returned | counts? |
|---|---|---|---|---|
| requests-3362 | 37.5 | checks for `AGENTS.md` at `/`, `~`, `~/sbwork`, the task folder | nothing from those paths | no |
| requests-3362 | 43.4 | `ls /usr/local/bin/python* /opt/homebrew/bin/python*` (end of a repo-reading command) | names of system interpreters | no (system tools, no task content) |
| flask-4045 | 29.9 | the same `AGENTS.md` check | nothing | no |
| flask-4045 | 68.4 | `rg --files ~/sbwork -g '*werkzeug*whl' -g pyvenv.cfg` | other tasks' env paths | **yes** |
| flask-4045 | 68.6 | `ls /private/tmp` | observer log folder names | **yes** |
| flask-4045 | 73.6 | `rg` in `/private/tmp/topic12-offline-*` and the pip cache | nothing | no |
| flask-4045 | 117.5, 120.1 | wrote and ran its own test in `/private/tmp/flask-4045-blueprint-verification` | its own file | no (own scratch) |
| flask-4992 | 45.2 | `rg --files -g AGENTS.md ~/sbwork ~/.agents` | nothing (exit 2; other tasks were chmod 000 under run_task_v4) | no |
| flask-4992 | 50.9 | the same `AGENTS.md` check | nothing outside the repo | no |
| flask-4992 | 98.4, 108.0 | wrote a pytest log and a mypy cache under `/tmp` | its own files | no |

This table covers every outside path that `review_stage_b.py` lists.

## Result

- requests-3362: clean.
- flask-4045: exposed. Its primary outcome is inconclusive. See
  EXPOSURE-AUDIT-flask-4045.md.
- flask-4992: clean.

## Never touched in any task

- oracle/, admission/ and cache/;
- the dataset, hidden tests and reference patches;
- the research archive.
