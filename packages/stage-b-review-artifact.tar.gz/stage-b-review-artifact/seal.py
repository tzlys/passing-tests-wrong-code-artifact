"""Seal Stage B inputs (run once, after observer qualification, before the first task).

  /opt/homebrew/anaconda3/bin/python3 seal.py
"""
import hashlib
import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ['DECLARATION.md', 'AMENDMENT-01.md', 'AMENDMENT-02.md', 'HARNESS-CORRECTIONS.txt', 'PLAN-zh.md',
         'admission.py', 'admission/summary.json', 'observer_lib.py', 'observer_qualify.py',
         'run_task.py', 'analyze_task.py', 'qualification/native_wrapper.py',
         'qualification/a0_schema_check.py', 'qualification/a1_planning_smoke.py',
         'qualification/A0-CORRECTION.txt', 'qualification/a0-attempt-2/result.json',
         'qualification/a1-attempt-1/result.json', 'observer-qualification/result.json',
         'observer-qualification/result-1.json', 'observer-qualification/result-2.json',
         'observer-qualification/result-3.json']


def main():
    if (HERE / 'SEAL.json').exists():
        raise SystemExit('SEAL.json already exists; the seal is written once')
    oq = json.loads((HERE / 'observer-qualification' / 'result.json').read_text())
    if not oq.get('qualified'):
        raise SystemExit('observer qualification has not passed')
    if any((HERE / 'runs').glob('*/result.json')) if (HERE / 'runs').exists() else False:
        raise SystemExit('a task was already launched; cannot seal afterwards')
    seal = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'protocol_sha256_prefix': 'ab84cac8', 'selection_sha256_prefix': '2b2cb1c7',
            'files': {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in FILES}}
    (HERE / 'SEAL.json').write_text(json.dumps(seal, indent=2))
    print(json.dumps(seal, indent=2))
    print('SEAL.json sha256:', hashlib.sha256((HERE / 'SEAL.json').read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
