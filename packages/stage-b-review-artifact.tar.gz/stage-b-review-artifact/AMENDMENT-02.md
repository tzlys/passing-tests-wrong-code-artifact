# Amendment 02: independent model-free re-grading on Linux (pre-task)

Written 2026-11-15 ~00:45 America/New_York.
- This is after the observer qualification (`observer-qualification/result-3.json`)
  and before any benchmark task has reached a model.
- Benchmark-task model calls so far: 0.
- Author decision: Yansong Li, 2026-11-15 00:40 ET.

## What is added
After the macOS pilot (and any expansion), the frozen artifacts of every
launched task are re-graded and re-checked on an AWS Linux host.
- **Artifacts**: `final.patch`, and the list of test-like commands that
  exited 0, with their working directories.
- **No model is called** on Linux.
- **Credentials**:
  - no OpenAI, Codex or ChatGPT credential is placed on the host or used there;
  - only the author's own AWS account is used, from the author's terminal.

1. **Official harness grading.** Each final patch is graded as a
   prediction with the official SWE-bench evaluation harness and its Docker
   images.
   - The harness release and image digests are recorded.
   - FAIL_TO_PASS and PASS_TO_PASS come from the same sealed parquet.
2. **Linux serial recheck.** Inside the same instance image, with the final
   patch applied, each recorded passing test-like command is run twice
   *as run* and twice *source-forced*, exactly as on macOS.
   - Absolute macOS paths (`~/sbwork/<id>/repo`) are rewritten to the
     container's repository path.
   - The rewrite rule is recorded.

## How results are used (fixed now)
- **Held-out correctness.**
  - Reported for both platforms: macOS native (DECLARATION step 2) and
    official harness on Linux.
  - The official Linux result is reported as the reference
    `resolved` value.
  - Any disagreement between the two platforms is reported per task as
    platform-dependent; neither is discarded.
- **The primary outcome and the continuation gate are unchanged.**
  - Both stay determined on macOS, where the executed-source and poller
    receipts exist.
  - For a primary candidate, the Linux recheck is reported as additional
    confirmation, but it can neither create nor remove a primary case.
- **If the Linux steps cannot be completed in time**, that is reported, and
  the macOS results stand as declared.

## Unchanged
Everything in PROTOCOL.txt, AMENDMENT-01 and DECLARATION.md not mentioned
here.
