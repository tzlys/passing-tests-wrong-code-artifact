#!/bin/bash
# Stage B 预检（只读）：不调用模型，不读取 ~/.codex 下的任何登录或配置文件，
# 不联网安装，不改动任何已有文件。结果写到本目录的 preflight/ 下。
# 用法：cd 到本脚本所在目录，运行  bash preflight.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/preflight"
mkdir -p "$OUT"
LOG="$OUT/preflight.txt"
: > "$LOG"
say(){ echo "$*" | tee -a "$LOG"; }
section(){ say ""; say "=== $1"; }

ARCHIVE="$HOME/Documents/ChatGPT/worksop/research-archive/topics/13-execution-window-evidence"
MEMSRC="$ARCHIVE/experiments/01-controlled-discovery/artifacts/memtrace-source/src"
CLI='/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
RUNTIME_PY="$HOME/Documents/Codex/research-continuations/2026-10-16-memory-scope/runtime/bin/python"
OLD_CLI_SHA='0d5ac7aae20c4eda6242428d5e218c55ba96d8763fda2a271088ff37104b9d28'
PARQUET_SHA='7a21f37b8bc179c7db5beeb14e88ac538ba283455c776e6b2535bbfb6e3551b4'

section "时间和机器"
say "utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
say "macOS: $(sw_vers -productVersion 2>/dev/null)  arch: $(uname -m)"
say "free disk (home): $(df -h "$HOME" | awk 'NR==2{print $4}')"

section "Codex CLI（10/19 记录的版本 0.162.0-alpha.17.2）"
if [ -x "$CLI" ]; then
  say "path exists"
  say "version: $("$CLI" --version 2>&1 | head -1)"
  NOW_SHA=$(shasum -a 256 "$CLI" | awk '{print $1}')
  say "sha256: $NOW_SHA"
  if [ "$NOW_SHA" = "$OLD_CLI_SHA" ]; then say "same binary as 10/19: YES"; else say "same binary as 10/19: NO (app 已更新，需重新做兼容性检查)"; fi
  "$CLI" app-server --help > "$OUT/app-server-help.txt" 2>&1; say "app-server --help exit: $? (全文见 preflight/app-server-help.txt)"
else
  say "CLI NOT FOUND at expected path"
  ls -d /Applications/ChatGPT.app/Contents/Resources/codex-cli* 2>&1 | tee -a "$LOG"
  say "which codex: $(which codex 2>/dev/null || echo none)"
fi

section "MemTrace 运行时 Python（10/19 用的是 3.12.14）"
if [ -x "$RUNTIME_PY" ]; then
  say "runtime: $("$RUNTIME_PY" --version 2>&1)"
  "$RUNTIME_PY" -B -c "
import sys; sys.path.insert(0, '$MEMSRC')
import memtrace
from memtrace.orchestration.run_coordinator import RunCoordinator
from memtrace.harness.adapter import CodexHarnessAdapter
print('memtrace import OK from archive src')
for m in ['pyarrow','pandas']:
    try: __import__(m); print(m, 'available')
    except Exception as e: print(m, 'missing')
" 2>&1 | tee -a "$LOG"
else
  say "runtime python NOT FOUND: $RUNTIME_PY"
fi

section "其他 Python 和环境工具（SWE-bench 的 requests/flask 需要 3.9 或 3.11）"
for p in python3.9 python3.10 python3.11 python3.12 python3 uv pyenv conda git; do
  loc=$(command -v $p 2>/dev/null)
  if [ -n "$loc" ]; then say "$p: $loc  $($p --version 2>&1 | head -1)"; else say "$p: none"; fi
done
[ -x /usr/bin/python3 ] && say "/usr/bin/python3: $(/usr/bin/python3 --version 2>&1)"

section "SWE-bench Lite parquet（10/19 记录 sha256 7a21f37b…）"
FOUND=0
while IFS= read -r f; do
  s=$(shasum -a 256 "$f" | awk '{print $1}')
  mark=""; [ "$s" = "$PARQUET_SHA" ] && mark="  <== MATCH" && FOUND=1
  say "$f  $s$mark"
done < <(find "$HOME/Documents/Codex" "$HOME/Documents/ChatGPT" -maxdepth 8 -name '*.parquet' -size +100k 2>/dev/null)
[ $FOUND = 1 ] && say "parquet found" || say "matching parquet NOT found under ~/Documents/Codex or ~/Documents/ChatGPT"

section "网络（只发 HEAD 请求，不下载）"
for u in https://github.com https://pypi.org/simple/ https://files.pythonhosted.org; do
  code=$(curl -s -o /dev/null -I -m 10 -w '%{http_code}' "$u"); say "$u -> $code"
done

section "完成"
say "请把 preflight/preflight.txt 的内容告诉 Claude（或直接说跑完了）。"
