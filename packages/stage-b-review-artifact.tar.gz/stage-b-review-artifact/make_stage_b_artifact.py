"""Build the Stage B review artifact (model-free, no task code executed).

    python3 -I -B make_stage_b_artifact.py <experiment-dir> <output-dir>

Copies the experiment folder into a clean staging tree. Then it:
- leaves out the bulky or private parts:
  - admission repo/venv copies and the cache;
  - Codex native state;
  - bytecode caches;
- drops `account/*` and `remoteControl/*` notifications from every .jsonl
  without inspecting them (they concern the operator's account, not the task);
- runs review_stage_b.py on the staged copy;
- writes stage-b-review-artifact.tar.gz, its SHA-256 and a manifest.
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

SRC, OUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
NAME = 'stage-b-review-artifact'
DROP_DIRS = {'cache', '__pycache__', 'native-state', 'venv', 'repo'}
DROP_METHOD_PREFIXES = ('account/', 'remoteControl/')


def keep(rel):
    return not any(part in DROP_DIRS for part in rel.parts)


def redact_jsonl(src, dst):
    kept = dropped = 0
    with open(src) as fi, open(dst, 'w') as fo:
        for line in fi:
            try:
                method = json.loads(line).get('method') or ''
            except ValueError:
                method = ''
            if method.startswith(DROP_METHOD_PREFIXES):
                dropped += 1
                continue
            fo.write(line)
            kept += 1
    return kept, dropped


def main():
    stage_root = Path(tempfile.mkdtemp())
    stage = stage_root / NAME
    redactions = {}
    for p in sorted(SRC.rglob('*')):
        rel = p.relative_to(SRC)
        if not keep(rel) or p.is_symlink() or not p.is_file():
            continue
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix == '.jsonl':
            kept, dropped = redact_jsonl(p, dst)
            if dropped:
                redactions[str(rel)] = dropped
        else:
            shutil.copy2(p, dst)
    shutil.copy2(SRC / 'ARTIFACT-README.md', stage / 'README.md')

    review = subprocess.run([sys.executable, '-I', '-B', str(stage / 'review_stage_b.py'),
                             '--json', str(stage_root / 'review.json')],
                            cwd=stage_root, capture_output=True, text=True)
    print(review.stdout[-4000:], review.stderr[-2000:])
    if review.returncode != 0:
        raise SystemExit('review failed on the staged copy; artifact not written')

    files = sorted(q for q in stage.rglob('*') if q.is_file())
    manifest = {'files': len(files), 'bytes': sum(q.stat().st_size for q in files),
                'redacted_notifications': redactions,
                'excluded_dir_names': sorted(DROP_DIRS)}
    (stage / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2))
    OUT.mkdir(parents=True, exist_ok=True)
    tgz = OUT / f'{NAME}.tar.gz'
    with tarfile.open(tgz, 'w:gz') as tf:
        tf.add(stage, arcname=NAME)
    digest = hashlib.sha256(tgz.read_bytes()).hexdigest()
    (OUT / f'{NAME}.tar.gz.sha256').write_text(f'{digest}  {tgz.name}\n')
    shutil.copy2(stage_root / 'review.json', OUT / f'{NAME}.review.json')
    print(json.dumps({'artifact': str(tgz), 'sha256': digest, **manifest}, indent=2))


if __name__ == '__main__':
    main()
