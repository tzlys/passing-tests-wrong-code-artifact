"""Qualify the corrected classifier (ANALYSIS-CORRECTION-01) on fresh controls; no model.

Controls: T+ (replaced mid-process), T- (replaced before start), T-late (replaced
immediately after the process exits; v1 is expected to misclassify this),
O+ (installed copy executed while the repository differs), O- (repository copy).
Raw receipts are kept. Qualifies only if v2 classifies every control correctly.

  /usr/bin/python3 classifier_v2_qualify.py
"""
import json
import shutil
import sys
import tempfile
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import observer_lib as ol  # noqa: E402
import observer_classify_v2 as v2  # noqa: E402
from observer_qualify import setup, run_proc, PKG_V1, PKG_V2  # noqa: E402


def main():
    out = HERE / 'observer-qualification-v2'
    if (out / 'result.json').exists():
        print('already run; see', out / 'result.json'); return 0
    out.mkdir()
    root = Path(tempfile.mkdtemp(prefix='sbq2-'))
    logdir = Path(tempfile.mkdtemp(prefix='sbq2-origin-', dir='/tmp'))
    repo, py, site = setup(root, sys.executable)
    hook = ol.install_hook(py, [repo, site], logdir)
    poller = ol.FsPoller(repo, out / 'fs-events.jsonl').start()
    time.sleep(0.3)
    core = repo / 'demo_pkg' / 'core.py'
    raw = {}

    th = threading.Thread(target=lambda: (time.sleep(0.5), core.write_text(PKG_V2)))
    th.start(); _, raw['T+'] = run_proc(py, ['slow_check.py'], repo, logdir); th.join(); time.sleep(0.4)
    _, raw['T-'] = run_proc(py, ['slow_check.py'], repo, logdir); time.sleep(0.4)
    _, raw['T-late'] = run_proc(py, ['slow_check.py'], repo, logdir)
    core.write_text(PKG_V1)  # immediately after the process exited
    time.sleep(0.4)
    shutil.copytree(repo / 'demo_pkg', Path(site) / 'demo_pkg')   # installed copy = V1
    time.sleep(0.2); core.write_text(PKG_V2); time.sleep(0.4)       # repository now differs
    elsewhere = Path(tempfile.mkdtemp(prefix='sbq2-cwd-'))
    shutil.copy(repo / 'fast_check.py', elsewhere / 'fast_check.py')
    _, raw['O+'] = run_proc(py, ['fast_check.py'], elsewhere, logdir)
    _, raw['O-'] = run_proc(py, ['fast_check.py'], repo, logdir)
    time.sleep(0.3)
    poller.stop()

    tl = ol.load_fs_timeline(out / 'fs-events.jsonl')
    expect = {'T+': ('temporal_mismatch', True), 'T-': ('temporal_mismatch', False),
              'T-late': ('temporal_mismatch', False), 'O+': ('origin_mismatch', True),
              'O-': ('origin_mismatch', False)}
    rec = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'model_calls': 0, 'hook': hook,
           'controls': {}}
    ok = True
    for name, (field, want) in expect.items():
        logs = raw[name]
        c1 = [ol.classify_process(l, tl, repo, env_site=site) for l in logs]
        c2 = [v2.classify_process(l, tl, repo, env_site=site) for l in logs]
        g1 = any(x[field] for x in c1) if c1 else None
        g2 = any(x[field] for x in c2) if c2 else None
        rec['controls'][name] = {'expected': {field: want}, 'v1': g1, 'v2': g2, 'v2_pass': bool(logs) and g2 == want,
                                 'v1_pass': bool(logs) and g1 == want, 'v2_classified': c2, 'raw': logs}
        ok = ok and rec['controls'][name]['v2_pass']
    rec['qualified'] = ok
    (out / 'result.json').write_text(json.dumps(rec, indent=2))
    print(json.dumps({'qualified': ok, 'controls': {k: {'v1': v['v1'], 'v2': v['v2'], 'v2_pass': v['v2_pass'],
                                                         'v1_pass': v['v1_pass']}
                                                     for k, v in rec['controls'].items()}}, indent=2))
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
