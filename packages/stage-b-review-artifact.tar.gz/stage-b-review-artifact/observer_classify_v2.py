"""Corrected process classifier (ANALYSIS-CORRECTION-01).

v1 (observer_lib.classify_process) widened the process end by 0.15 s, so a
change the poller detected shortly *after* a process exited could be counted
as a change during it. v2:
  - temporal mismatch only if the poller detected a replacement of the bytes
    the process read at or before the process end;
  - a replacement detected within one poll interval after the end is
    reported as `boundary_ambiguous`, not as a mismatch;
  - origin uses the repository hash at the moment of the read (no slack).
Receipts and the recorder are unchanged; this is analysis-only.
"""
import os
from pathlib import Path

from observer_lib import hash_at  # noqa: F401  (same timeline helpers)


def classify_process(proc, timeline, repo_root, env_site=None, interval=0.1):
    repo = str(Path(repo_root).resolve()) + os.sep
    out = {'pid': proc['pid'], 'argv': proc['argv'], 'cwd': proc['cwd'], 'start': proc['start'],
           'end': proc['end'], 'repo_reads': 0, 'temporal': [], 'boundary_ambiguous': [], 'origin': [],
           'stale_pyc': [], 'classifier': 'v2'}
    for r in proc['reads']:
        path = r['path']
        if path.startswith(repo) and path.endswith('.py'):
            out['repo_reads'] += 1
            changes = [c for c in timeline.get(path, []) if c['event'] != 'initial' and c['t'] > r['t']]
            during = [c for c in changes if c['t'] <= proc['end']]
            after = [c for c in changes if proc['end'] < c['t'] <= proc['end'] + interval]
            if during and during[-1].get('sha256') not in (None, r['sha256']):
                out['temporal'].append({'path': path, 'read_sha256': r['sha256'],
                                        'replaced_by': during[-1].get('sha256'),
                                        'detected_at': [c['t'] for c in during]})
            elif after and after[0].get('sha256') not in (None, r['sha256']):
                out['boundary_ambiguous'].append({'path': path, 'read_sha256': r['sha256'],
                                                  'detected_after_end_s': after[0]['t'] - proc['end']})
        elif env_site and path.startswith(str(Path(env_site).resolve()) + os.sep) and path.endswith('.py'):
            rel = os.path.relpath(path, str(Path(env_site).resolve()))
            for cand in (os.path.join(repo, rel), os.path.join(repo, 'src', rel)):
                ws_hash = hash_at(timeline, cand, r['t'])
                if ws_hash is not None and ws_hash != r['sha256']:
                    out['origin'].append({'executed': path, 'repository_file': cand,
                                          'executed_sha256': r['sha256'], 'repository_sha256': ws_hash})
        if path.endswith('.pyc') and r.get('pyc_header') and path.startswith(repo):
            hdr = bytes.fromhex(r['pyc_header'])
            if int.from_bytes(hdr[4:8], 'little') == 0:
                mtime = int.from_bytes(hdr[8:12], 'little')
                size = int.from_bytes(hdr[12:16], 'little')
                src = os.path.join(os.path.dirname(os.path.dirname(path)),
                                   os.path.basename(path).split('.')[0] + '.py')
                srcs = [x for x in timeline.get(src, []) if x['t'] <= r['t'] and x['event'] != 'deleted']
                if srcs:
                    s = srcs[-1]
                    if (s['mtime_ns'] // 1_000_000_000) & 0xFFFFFFFF != mtime or (s['size'] & 0xFFFFFFFF) != size:
                        out['stale_pyc'].append({'pyc': path, 'source': src})
    out['temporal_mismatch'] = bool(out['temporal'])
    out['origin_mismatch'] = bool(out['origin'] or out['stale_pyc'])
    return out
